"""Thin client for Floppy's REST API (/api/v1)."""

import hashlib
import json
import time
from urllib.parse import urlencode

from . import cache, common, perf

CACHE_PREFIX = "floppy:"

# Fields Floppy updates for its own bookkeeping (metadata_fetched_at, scored_at, popularity and
# ranking scores...). The add-on never shows them, so a change in them alone must not reload widgets.
# Of the time fields only updated_at is read (it orders Continue Watching).
_SHOWN_TIME_FIELDS = {"updated_at"}
_HIDDEN_FIELDS = {"final_score", "display_score", "score_breakdown"}
_HIDDEN_PARTS = ("popularity", "opencritic")


def _shown(value):
    """``value`` without the fields above, for telling whether a refresh changes what widgets show."""
    if isinstance(value, dict):
        return {
            k: _shown(v) for k, v in value.items()
            if not (
                (k.endswith("_at") and k not in _SHOWN_TIME_FIELDS)
                or k in _HIDDEN_FIELDS
                or any(part in k for part in _HIDDEN_PARTS)
            )
        }
    if isinstance(value, list):
        return [_shown(v) for v in value]
    return value


class FloppyError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


class FloppyAPI:
    def __init__(self, base_url=None, token=None, timeout=None):
        self.base_url = (base_url or common.setting("base_url")).strip().rstrip("/")
        self.token = (token or common.setting("token")).strip()
        self.timeout = timeout or common.setting_int("timeout", 15)
        token_hash = hashlib.sha1(
            "{}|{}".format(self.base_url, self.token).encode("utf-8")
        ).hexdigest()[:10]
        self._cache_ns = "{}{}:".format(CACHE_PREFIX, token_hash)
        # Widgets show a cached list even when it is out of date; the service refreshes it.
        self.serve_stale = False

    # -- plumbing -----------------------------------------------------------

    @property
    def configured(self):
        return bool(self.base_url and self.token)

    def _url(self, path, params=None):
        url = "{}/api/v1/{}".format(self.base_url, path.strip("/") + "/")
        if params:
            pairs = []
            for key, value in params.items():
                if value is None or value == "":
                    continue
                if isinstance(value, (list, tuple)):
                    pairs.extend((key, v) for v in value)
                else:
                    pairs.append((key, value))
            if pairs:
                url += "?" + urlencode(pairs)
        return url

    def request(self, method, path, params=None, body=None):
        if not self.configured:
            raise FloppyError("Floppy address or API token is not set")
        # Imported here: a widget served from the cache never needs the network stack (~40 ms).
        import ssl
        from urllib.error import HTTPError, URLError
        from urllib.request import Request, urlopen

        url = self._url(path, params)
        data = None
        headers = {
            "Authorization": "Bearer {}".format(self.token),
            "Accept": "application/json",
            "User-Agent": "plugin.video.floppy/1.0 (Kodi)",
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = Request(url, data=data, headers=headers, method=method)
        common.log("{} {}".format(method, url))
        context = ssl.create_default_context() if url.startswith("https") else None
        try:
            with perf.span("floppy_http"), urlopen(req, timeout=self.timeout, context=context) as resp:
                raw = resp.read()
                if not raw:
                    return None
                return json.loads(raw.decode("utf-8"))
        except HTTPError as exc:
            detail = ""
            try:
                detail = json.loads(exc.read().decode("utf-8")).get("detail", "")
            except Exception:  # noqa: BLE001 - error body is best effort
                pass
            raise FloppyError(detail or "HTTP {}".format(exc.code), exc.code)
        except (URLError, OSError, ValueError) as exc:
            raise FloppyError("Could not reach Floppy: {}".format(exc))

    def cache_key(self, path, params):
        return self._cache_ns + path + "?" + json.dumps(params or {}, sort_keys=True)

    def get(self, path, params=None, ttl=0):
        key = self.cache_key(path, params)
        if ttl > 0:
            if self.serve_stale:
                cache.track_widget_key(key, path, params or {}, ttl)
            entry = cache.get_entry(key)
            if entry:
                stored, expires, raw = entry
                if stored is None:
                    stored = expires - ttl
                now = time.time()
                # Out of date once expired, or stored before the last change by this or
                # another add-on (e.g. TMDb Helper).
                current = expires >= now and stored >= common.data_changed_time()
                if current or (self.serve_stale and stored >= now - cache.STALE_MAX):
                    try:
                        data = json.loads(raw)
                    except ValueError:
                        data = None
                    if data is not None:
                        perf.add("floppy_cache_hit" if current else "floppy_stale_hit")
                        return data
        data = self.request("GET", path, params)
        if ttl > 0 and data is not None:
            cache.set(key, data, ttl)
        return data

    def refresh(self, key, path, params, ttl):
        """Fetch a cached request again; True when widgets would show something different."""
        if key != self.cache_key(path, params):
            return False  # cached under another address or token
        data = self.request("GET", path, params)
        if data is None:
            return False
        # Read after the request: a widget may have fetched and cached the same answer meanwhile.
        entry = cache.get_entry(key)
        cache.set(key, data, ttl)
        if not entry:
            return True
        try:
            old = json.loads(entry[2])
        except ValueError:
            return True
        return _shown(old) != _shown(data)

    def invalidate(self):
        cache.delete_prefix(CACHE_PREFIX)

    # -- endpoints ----------------------------------------------------------

    def info(self):
        return self.request("GET", "info")
    
    def scrobble(self, body):
        return self.request("POST", "scrobble", body=body)

    def media(self, media_type, ttl=0, **params):
        return self.get("media/{}".format(media_type), params, ttl)

    def playback_progress(self, media_types, completed=False, limit=50, offset=0, ttl=0):
        params = {"media_type": ",".join(media_types), "limit": limit, "offset": offset}
        if completed is not None:
            params["completed"] = "true" if completed else "false"
        return self.get("playback/progress", params, ttl)

    def put_progress(self, body):
        return self.request("PUT", "playback/progress", body=body)

    def delete_progress(self, body):
        return self.request("DELETE", "playback/progress", body=body)

    def recommendations(self, media_type, limit=20, offset=0, ttl=0):
        params = {"media_type": media_type, "limit": limit, "offset": offset}
        return self.get("recommendations", params, ttl)

    def discover(self, media_type, show_more=False, ttl=0):
        params = {"media_type": media_type}
        if show_more:
            params["show_more"] = "1"
        return self.get("discover", params, ttl)

    def history(self, media_types, limit=20, offset=0, ttl=0):
        params = {"flat": "1", "media_type": ",".join(media_types), "limit": limit, "offset": offset}
        return self.get("history", params, ttl)

    def calendar(self, start_date, end_date, ttl=0):
        params = {"start_date": start_date, "end_date": end_date, "limit": 500}
        return self.get("calendar", params, ttl)

    def lists(self, ttl=0):
        return self.get("lists", {"limit": 200}, ttl)

    def list_items(self, list_id, limit=20, offset=0, ttl=0):
        return self.get("lists/{}/items".format(list_id), {"limit": limit, "offset": offset}, ttl)

    def home(self, limit=30, ttl=0):
        return self.get("home", {"limit": limit}, ttl)

    def watch_movie(self, source, media_id):
        return self.request("POST", "media/movie/{}/{}/watch".format(source, media_id), body={})

    def unwatch_movie(self, source, media_id):
        """Remove the most recent play of a movie."""
        return self.request("DELETE", "media/movie/{}/{}/watch".format(source, media_id))

    def consumptions(self, media_type, source, media_id, lmt=None):
        return self.get("media/{}/{}/{}/history".format(media_type, source, media_id),
                        {"library_media_type": lmt, "limit": 200})

    def delete_consumption(self, media_type, source, media_id, consumption_id, lmt=None):
        path = "media/{}/{}/{}/history/{}".format(media_type, source, media_id, consumption_id)
        return self.request("DELETE", path, params={"library_media_type": lmt})

    def add_to_watchlist(self, media_type, source, media_id):
        body = {"media_id": str(media_id), "source": source, "status": 0}
        return self.request("POST", "media/{}".format(media_type), body=body)

    def untrack(self, media_type, source, media_id, lmt=None):
        return self.request("DELETE", "media/{}/{}/{}".format(media_type, source, media_id),
                            params={"library_media_type": lmt})
    
    def show_detail(self, tmdb_id, lmt=None, ttl=0):
        return self.get("media/tv/tmdb/{}".format(tmdb_id), {"library_media_type": lmt}, ttl)

    def season_episodes(self, tmdb_id, season, lmt=None, ttl=0):
        return self.get("media/tv/tmdb/{}/{}/episodes".format(tmdb_id, season),
                        {"limit": 200, "library_media_type": lmt}, ttl)

    def watch_episode(self, source, media_id, season, episode, lmt=None):
        path = "media/tv/{}/{}/{}/episodes/{}/watch".format(source, media_id, season, episode)
        return self.request("POST", path, body={"library_media_type": lmt} if lmt else {})

    def unwatch_episode(self, source, media_id, season, episode, lmt=None):
        path = "media/tv/{}/{}/{}/episodes/{}/watch".format(source, media_id, season, episode)
        return self.request("DELETE", path, params={"library_media_type": lmt},
                            body={"library_media_type": lmt} if lmt else None)
    
    def search(self, media_type, query, limit=20, ttl=0):
        return self.get("search/{}".format(media_type), {"search": query, "limit": limit}, ttl)
