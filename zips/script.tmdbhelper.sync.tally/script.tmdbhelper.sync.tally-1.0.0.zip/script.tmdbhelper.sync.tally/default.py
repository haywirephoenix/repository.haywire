"""TMDbHelper Sync - Tally (Installer): the add-on that brings in the sync provider
(script.module.tmdbhelper.sync.tally, a module Kodi's repository browser doesn't list).
Opening it offers the steps to set the sync up."""
import xbmc
import xbmcgui

SYNC = "script.module.tmdbhelper.sync.tally"
TALLY = "plugin.video.tally"
TMDBHELPER = "plugin.video.themoviedb.helper"
HEADING = "TMDbHelper Sync - Tally"


def main():
    options = [
        ("TMDbHelper settings", "Choose Tally for history and progress, watchlist and scrobbling.",
         "Addon.OpenSettings({})".format(TMDBHELPER)),
        ("Tally settings", "Your TMDb key, players and what Tally tracks.",
         "Addon.OpenSettings({})".format(TALLY)),
        ("Tally sync settings", "Whether TMDbHelper or Tally records playback.",
         "Addon.OpenSettings({})".format(SYNC)),
    ]
    items = []
    for label, help_text, _ in options:
        item = xbmcgui.ListItem(label, help_text, offscreen=True)
        items.append(item)
    choice = xbmcgui.Dialog().select(HEADING, items, useDetails=True)
    if choice >= 0:
        xbmc.executebuiltin(options[choice][2])


if __name__ == "__main__":
    main()
