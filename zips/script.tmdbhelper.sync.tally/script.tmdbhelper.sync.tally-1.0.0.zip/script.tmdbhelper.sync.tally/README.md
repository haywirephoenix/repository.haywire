# TMDbHelper Sync - Tally (Installer)

Installs [TMDbHelper Sync - Tally](https://github.com/haywirephoenix/script.module.tmdbhelper.sync.tally),
the Tally sync provider for TMDbHelper. That provider is a module (TMDbHelper finds it by its id,
`script.module.tmdbhelper.sync.tally`), and Kodi's repository browser doesn't list modules, so
this small add-on is what you install from [repository.haywire](https://github.com/haywirephoenix/repository.haywire):
Kodi brings the module, Tally and TMDbHelper with it.

Open it (Program add-ons) to set the sync up:

1. **TMDbHelper settings**: choose Tally for history and progress, watchlist and scrobbling.
2. **Tally settings**: your TMDb key, players and what Tally tracks.
3. **Tally sync settings**: whether TMDbHelper or Tally records playback.

Published to repository.haywire on a version bump (`.github/workflows/publish.yml`).
