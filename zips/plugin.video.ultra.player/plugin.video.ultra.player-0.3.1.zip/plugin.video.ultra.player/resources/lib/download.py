"""Download a title for later (the Download context menu item: context.py). The same sources are
asked as for playing (player.find_offers). The first one that can be downloaded is (setting
resolve "auto"), or the one picked ("choose"):
- a direct link: into setting download_folder, with Kodi's background progress bar;
- a torrent: handed to a torrent add-on that downloads without playing (streams.
  TORRENT_DOWNLOADERS: Torrest), which shows its progress itself. Its play path is kept, so
  playing the title streams from that torrent, with no lookup.
Add-on links (player add-ons, YouTube) can't be downloaded. downloads.py keeps the index
playing checks first.

Run again on a title: while it downloads it offers to stop (the part is kept, and a later
Download carries on from it); once downloaded, to delete it.
"""
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import downloads  # noqa: E402
import player  # noqa: E402
import streams  # noqa: E402

HEADING = "Download"
STOP = "ultra.player.download.stop."  # + the title's key, on Home: stop that download


def notify(message, error=False):
    xbmcgui.Dialog().notification("Ultra Player", message,
                                  xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 5000)


def folder():
    """The download folder, created if missing; None (after saying why) if it can't be used."""
    setting = xbmcaddon.Addon(player.ADDON_ID).getSetting("download_folder")
    path = xbmcvfs.translatePath(setting or os.path.join(player.data_dir(), "downloads"))
    if "://" in path:
        notify("Downloads need a folder on this device, not {}".format(path.split("://")[0]), error=True)
        return None
    try:
        os.makedirs(path, exist_ok=True)
    except OSError as e:
        notify("Can't use the download folder: {}".format(e), error=True)
        return None
    return path


def size(n):
    return "{:.0f} MB".format(n / 1e6) if n < 1e9 else "{:.1f} GB".format(n / 1e9)


def run(kind, values):
    if not (values.get("tmdb") or values.get("imdb")):
        notify("No TMDb or IMDb id for this {}".format(kind), error=True)
        return
    data = player.data_dir()
    name = downloads.file_name(kind, values, "")[:-len(".mp4")]
    entry = downloads.find(data, kind, values)
    home = xbmcgui.Window(10000)
    stop_key = STOP + downloads.key(kind, values)
    dialog = xbmcgui.Dialog()
    if entry and entry.get("status") == "downloading":
        if dialog.yesno(HEADING, "{} is downloading.[CR]Stop it? What's downloaded so far is kept, and Download "
                                 "carries on from there.".format(name)):
            home.setProperty(stop_key, "1")
        return
    if entry and entry.get("status") == "client":
        notify("{} is with the torrent add-on: see its Torrents".format(name))
        return
    if entry and entry.get("status") == "done" and os.path.exists(entry.get("file") or ""):
        if dialog.yesno(HEADING, "{} is downloaded ({}).[CR]Delete the download?".format(name, size(entry.get("size") or 0))):
            try:
                os.remove(entry["file"])
            except OSError:
                pass
            downloads.update(data, kind, values, status="deleted")
            notify("Deleted {}".format(name))
        return

    target_dir = folder()
    if not target_dir:
        return
    offered, why = player.find_offers(kind, values)
    clients = {a for a, _ in streams.TORRENT_DOWNLOADERS if player.has_addon(a)}
    # (source, stream, (what to download, how), what plays it)
    can = []
    for source_name, stream, (path, how) in offered:
        if how == "url":
            can.append((source_name, stream, (path, "url"), path))
        elif how == "torrent" and streams.torrent_download(stream, clients):
            can.append((source_name, stream, (streams.torrent_download(stream, clients), "client"), path))
    if not can:
        notify(why if not offered else "Nothing to download: these are add-on links, which only play"
               + ("" if clients else " (torrents need Torrest)"), error=True)
        return
    chosen = player.choose_offer([c[:3] for c in can], values, "Download")
    if chosen is None:
        return
    source_name, stream, (url, how) = chosen
    if how == "client":
        play_path = next(c[3] for c in can if c[2][0] == url)
        player.log("download {}: handed to the torrent add-on: {}".format(name, url.split("?")[0]))
        downloads.update(data, kind, values, title=name, file="", url=play_path, status="client")
        xbmc.executebuiltin('RunPlugin("{}")'.format(url))
        notify("Torrest is downloading {}".format(name))
        return
    target = os.path.join(target_dir, downloads.file_name(kind, values, url))
    label, details = streams.describe(stream)
    player.log("download {}: {} from {} ({} {})".format(name, target, source_name, label, details))
    downloads.update(data, kind, values, title=name, file=target, url=url, status="downloading", size=0, done=0)
    home.clearProperty(stop_key)
    monitor = xbmc.Monitor()
    bar = xbmcgui.DialogProgressBG()
    bar.create("Downloading", name)
    last = [0.0]

    def progress(done, total):
        now = time.time()
        if now - last[0] < 1:
            return
        last[0] = now
        bar.update(int(done * 100 / total) if total else 0, "Downloading",
                   "{}: {}{}".format(name, size(done), " of " + size(total) if total else ""))
        downloads.update(data, kind, values, done=done, size=total)

    def stopped():
        return monitor.abortRequested() or home.getProperty(stop_key) == "1"

    try:
        result = downloads.fetch(url, target, progress, stopped)
    except OSError as e:
        result = None
        player.log("download {} failed: {}".format(name, e))
        downloads.update(data, kind, values, status="failed")
        notify("Download failed: {}".format(name), error=True)
    finally:
        bar.close()
        home.clearProperty(stop_key)
    if result == "done":
        downloads.update(data, kind, values, status="done", size=os.path.getsize(target), done=os.path.getsize(target))
        notify("Downloaded {}".format(name))
    elif result == "stopped":
        downloads.update(data, kind, values, status="stopped")
        if not monitor.abortRequested():
            notify("Stopped {}: Download carries on from there".format(name))
