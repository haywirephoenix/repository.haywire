"""Sources: Stremio-protocol add-ons (Stremio's and Nuvio's), found by their manifest URL
(store.py; Manage sources), that Ultra Player asks for streams (player.py).

The protocol (https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/protocol.md):
- An add-on is its manifest URL. Settings an add-on's configure page chose live in that URL,
  in its path (/<config>/manifest.json) or query (manifest.json?...); every other request is
  built from the same base and keeps the query.
- manifest.json: name, types, resources ("stream", or {"name": "stream", "types", "idPrefixes"}),
  idPrefixes, behaviorHints.configurable (then <base>/configure is its configure page).
- Streams: <base>/stream/<movie|series>/<id>.json -> {"streams": [...]}. id: the IMDb id
  (tt1375666), for an episode the show's plus season and episode (tt0944947:1:2); add-ons
  that take TMDb ids say so in idPrefixes (tmdb:27205, tmdb:1399:1:2).
- A stream: name, title / description (shown), and one of url (played, with
  behaviorHints.proxyHeaders.request as Kodi's |headers), ytId (YouTube add-on), infoHash (a
  torrent: only with a torrent add-on, TORRENT_PLAYERS), externalUrl (a web page: left out).

Pure functions here are tested (tests/test_streams.py); nothing here imports xbmc.
"""
import json
import re
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import quote, unquote, urlencode, urlsplit, urlunsplit

USER_AGENT = "Mozilla/5.0 (Kodi; plugin.video.ultra.player) Stremio-addon-client"
TIMEOUT = 15
TORRENT_PLAYERS = (
    ("plugin.video.elementum", "plugin://plugin.video.elementum/play?uri={magnet}"),
    ("plugin.video.torrest", "plugin://plugin.video.torrest/play_magnet?magnet={magnet}"),
)
# Torrent add-ons that download a torrent (just the stream's file, with index) without playing
# it, for Download: they show its progress themselves.
TORRENT_DOWNLOADERS = (
    ("plugin.video.torrest", "plugin://plugin.video.torrest/download_magnet?magnet={magnet}"),
)
# Why a stream can't play (classify), as the log and the "no streams" notice say it.
DROPPED = {
    "torrent": "torrents (needs Elementum or Torrest, or a debrid service set up in the add-on)",
    "youtube": "YouTube videos (needs the YouTube add-on)",
    "web": "web pages",
    "empty": "streams with nothing to play",
}
_WEB_ADDON = re.compile(r"[?&#]addon=([^&#\s]+)", re.I)


def manifest_link(text):
    """The https manifest URL behind a pasted add-on link: stremio:// install links open over
    https (as Stremio does), and Stremio Web links carry it in addon=."""
    text = str(text or "").strip().strip("'\"<>").strip()
    lower = text.lower()
    if lower.startswith("stremio:"):
        rest = text[len("stremio:"):].lstrip("/")
        return rest if rest.lower().startswith(("http://", "https://")) else ("https://" + rest if rest else "")
    if "addon=" in lower and ("stremio.com" in lower or "strem.io" in lower):
        m = _WEB_ADDON.search(text)
        if m:
            return manifest_link(unquote(m.group(1)))
    return text


def base_and_query(manifest_url):
    """(base URL, query) of a manifest URL: everything before /manifest.json, and its query."""
    parts = urlsplit(manifest_url)
    path = parts.path
    if path.endswith("/manifest.json"):
        path = path[:-len("/manifest.json")]
    return urlunsplit((parts.scheme, parts.netloc, path.rstrip("/"), "", "")), parts.query


def configure_url(manifest_url):
    base, query = base_and_query(manifest_url)
    return base + "/configure" + ("?" + query if query else "")


def resource_url(manifest_url, resource, media_type, item_id):
    base, query = base_and_query(manifest_url)
    url = "{}/{}/{}/{}.json".format(base, resource, media_type, quote(str(item_id), safe=":"))
    return url + ("?" + query if query else "")


def _stream_resource(manifest):
    for resource in manifest.get("resources") or []:
        if resource == "stream":
            return {}
        if isinstance(resource, dict) and resource.get("name") == "stream":
            return resource
    return None


def supports(manifest, media_type, item_id):
    """Whether the add-on gives streams for this type and id (its types and idPrefixes)."""
    resource = _stream_resource(manifest or {})
    if resource is None:
        return False
    types = resource.get("types") or manifest.get("types") or []
    prefixes = resource.get("idPrefixes") or manifest.get("idPrefixes")
    if media_type not in types:
        return False
    return not prefixes or any(str(item_id).startswith(p) for p in prefixes)


def item_ids(kind, values):
    """The stream ids to try for an item, best first: IMDb, then TMDb."""
    out = []
    for prefix, key in (("", "imdb"), ("tmdb:", "tmdb")):
        value = values.get(key)
        if not value:
            continue
        base = prefix + str(value)
        if kind == "episode":
            if not (values.get("season") and values.get("episode")):
                continue
            base = "{}:{}:{}".format(base, values["season"], values["episode"])
        out.append(base)
    return out


def check_manifest(manifest):
    """None if manifest is an add-on the player can use, else what's wrong."""
    if not isinstance(manifest, dict) or not manifest.get("id"):
        return "Not an add-on manifest"
    if _stream_resource(manifest) is None:
        return "{} gives no streams (only {})".format(manifest.get("name") or manifest["id"], ", ".join(
            r if isinstance(r, str) else str(r.get("name")) for r in manifest.get("resources") or []) or "nothing")
    return None


def playable(stream, installed=()):
    """(path, kind) Kodi can play for a stream, or None. installed: add-on ids present."""
    return classify(stream, installed)[0]


def classify(stream, installed=()):
    """((path, kind) or None, why not: a DROPPED key) for a stream."""
    if not isinstance(stream, dict):
        return None, "empty"
    hints = stream.get("behaviorHints") or {}
    if stream.get("url"):
        headers = ((hints.get("proxyHeaders") or {}).get("request") or {}) if isinstance(hints, dict) else {}
        url = str(stream["url"])
        if headers:
            url += "|" + urlencode({str(k): str(v) for k, v in headers.items()})
        return (url, "url"), None
    if stream.get("ytId"):
        if "plugin.video.youtube" not in installed:
            return None, "youtube"
        return ("plugin://plugin.video.youtube/play/?video_id={}".format(stream["ytId"]), "youtube"), None
    if stream.get("infoHash"):
        magnet = "magnet:?xt=urn:btih:{}".format(stream["infoHash"])
        for addon, template in TORRENT_PLAYERS:
            if addon in installed:
                path = template.format(magnet=quote(magnet, safe=""))
                if stream.get("fileIdx") is not None:
                    path += "&index={}".format(stream["fileIdx"])
                return (path, "torrent"), None
        return None, "torrent"
    return None, "web" if stream.get("externalUrl") else "empty"


def torrent_download(stream, installed=()):
    """The torrent add-on path that downloads a torrent stream (no playing), or None."""
    if not isinstance(stream, dict) or not stream.get("infoHash"):
        return None
    magnet = "magnet:?xt=urn:btih:{}".format(stream["infoHash"])
    for addon, template in TORRENT_DOWNLOADERS:
        if addon in installed:
            path = template.format(magnet=quote(magnet, safe=""))
            if stream.get("fileIdx") is not None:
                path += "&index={}".format(stream["fileIdx"])
            return path
    return None


def redact(url):
    """url without the add-on's settings (they can hold a debrid key): host, then <config>
    where the manifest link had a path or query before the resource."""
    parts = urlsplit(url)
    path = parts.path
    for resource in ("/stream/", "/manifest.json", "/configure"):
        if resource in path:
            config, rest = path.split(resource, 1)
            path = ("/<config>" if config.strip("/") else "") + resource + rest
            break
    return "{}://{}{}{}".format(parts.scheme, parts.netloc, path, "?<config>" if parts.query else "")


def describe(stream):
    """(label, details) for the source list: the stream's name and its title / description."""
    name = " ".join(str(stream.get("name") or "").split())
    details = " ".join(str(stream.get("title") or stream.get("description") or "").split())
    return name or details or "Stream", details if name else ""


def fetch_json(url, timeout=TIMEOUT):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8", "replace"))


def gather(sources, manifests, kind, values, timeout=TIMEOUT):
    """([(source index, source name, stream)], report) from every source that supports the
    item, asked at once, each given timeout seconds. manifests: {manifest URL: manifest}. report: per source
    {"name", "url" (redacted), "streams" (how many), "seconds", "error"}, or "skipped" with
    why it wasn't asked."""
    media_type = "movie" if kind == "movie" else "series"
    ids = item_ids(kind, values)
    results, threads, report = {}, [], []

    def ask(n, url, entry):
        started = time.time()
        try:
            found = fetch_json(url, timeout).get("streams") or []
            results[n] = [(n, entry["name"], s) for s in found]
            entry["streams"] = len(found)
        except urllib.error.HTTPError as e:
            entry["error"] = "HTTP {}".format(e.code)
        except (OSError, ValueError, AttributeError) as e:
            entry["error"] = "timed out" if "timed out" in str(e) else (str(e) or e.__class__.__name__)
        entry["seconds"] = round(time.time() - started, 1)

    for n, source in enumerate(sources):
        manifest = manifests.get(source.get("manifest"))
        entry = {"name": source.get("name") or (manifest or {}).get("name") or "Source",
                 "url": redact(source.get("manifest") or ""), "streams": 0}
        report.append(entry)
        if manifest is None:
            entry["skipped"] = "its manifest couldn't be loaded"
            continue
        item_id = next((i for i in ids if supports(manifest, media_type, i)), None)
        if item_id is None:
            entry["skipped"] = "no {} streams for ids {}".format(media_type, ", ".join(ids) or "(none)")
            continue
        url = resource_url(source["manifest"], "stream", media_type, item_id)
        entry["url"] = redact(url)
        thread = threading.Thread(target=ask, args=(n, url, entry))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join(timeout + 1)
    for entry in report:
        if "skipped" not in entry and "seconds" not in entry:
            entry["error"], entry["seconds"] = "timed out", float(timeout)
    return [found for n in sorted(results) for found in results[n]], report


def read_cache(path):
    """{manifest URL: manifest} saved by the settings editor and the player."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_cache(path, cache):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cache, f)


def manifests(sources, cache_path, refresh=()):
    """{manifest URL: manifest} for sources: from the cache, fetched (and saved) when missing
    or in refresh. Unreachable ones are left out."""
    cache, changed = read_cache(cache_path), False
    for source in sources:
        url = source.get("manifest")
        if url and (url not in cache or url in refresh):
            try:
                cache[url], changed = fetch_json(url), True
            except (OSError, ValueError):
                continue
    if changed:
        write_cache(cache_path, cache)
    return {s["manifest"]: cache[s["manifest"]] for s in sources if s.get("manifest") in cache}
