"""Playing a title from the sources (plugin://plugin.video.ultra.player/play?...).

The play URL carries what's known about the title, the same names a TMDb Helper player file
fills in (resources/players/ultra.player.json):

    kind      movie or episode
    tmdb, imdb, tvdb   ids (an episode's are its show's)
    season, episode    an episode's numbers
    title     the movie's title, or the episode's
    showname  an episode's show
    year, poster, fanart

First (setting local_first) a copy that needs no lookup plays: the title downloaded
(downloads.py), in the Kodi library, or being downloaded (its link). Otherwise every source is
asked for streams at once (a player source, another add-on through a TMDb Helper player file,
offers its play path: players.py); then the first playable one plays, in the sources' order
(setting resolve "auto"), or the one picked from the list ("choose"). find_offers and
choose_offer are shared with downloading (download.py). As a resolvable plugin it hands Kodi the
stream through setResolvedUrl; run by RunPlugin (no handle) it plays it itself.

For skins it reports on Home (window 10000), so a loading screen can follow:
    ultra.player.state    "choosing" while the source list shows, "cancelled" when it was left
                          without a choice, "failed" when nothing plays (with ultra.player.message
                          saying why), "handing" once a stream is handed to Kodi or another
                          add-on (Torrest can take a while to start reporting; the skin clears it
                          when something does).
A skin with its own source list (SKIN_SOURCES in its 1080i folder, skin.ultra's is laid out like
its seasons page) gets it in place of Kodi's select dialog: list 50, each item's label the
stream, label2 its details and property "source" the source it came from. A loading screen that
was left with Back sets ultra.loading.cancel: then nothing is listed or played.
"""
import json
import os
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import downloads  # noqa: E402
import players  # noqa: E402
import store  # noqa: E402
import streams  # noqa: E402

ADDON_ID = "plugin.video.ultra.player"
STATE, MESSAGE = "ultra.player.state", "ultra.player.message"
# The skin's loading screen was left with Back (skin.ultra sets it): drop the play.
SKIN_CANCEL = "ultra.loading.cancel"
SKIN_SOURCES = "ultra.player-sources.xml"
SKIN_SOURCES_LIST = 50


def log(msg):
    xbmc.log("[{}] {}".format(ADDON_ID, msg), xbmc.LOGINFO)


def data_dir():
    return xbmcvfs.translatePath("special://profile/addon_data/{}/".format(ADDON_ID))


def local_first():
    return xbmcaddon.Addon(ADDON_ID).getSetting("local_first") != "false"


def settings():
    addon = xbmcaddon.Addon(ADDON_ID)
    resolve = addon.getSetting("resolve") or "auto"
    try:
        timeout = max(3, min(60, int(addon.getSetting("timeout") or streams.TIMEOUT)))
    except ValueError:
        timeout = streams.TIMEOUT
    return resolve, timeout


def values_from(params):
    """The play URL's values, with the names streams.item_ids and the list item use."""
    values = {k: str(params.get(k) or "") for k in ("tmdb", "imdb", "tvdb", "season", "episode", "title",
                                                    "showname", "year", "poster", "fanart")}
    kind = "episode" if params.get("kind") == "episode" else "movie"
    return kind, values


def fail(handle, message):
    home = xbmcgui.Window(10000)
    home.setProperty(MESSAGE, message)
    home.setProperty(STATE, "failed")
    xbmcgui.Dialog().notification("Ultra Player", message, xbmcgui.NOTIFICATION_WARNING, 5000)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def no_streams_reason(kind, report, dropped):
    """The notice when nothing can play: the first source's reason, in a few words."""
    for entry in report:
        if dropped.get(entry["name"]):
            why, n = max(dropped[entry["name"]].items(), key=lambda kv: kv[1])
            return "{}: {} {}".format(entry["name"], n, streams.DROPPED[why])
    for entry in report:
        if entry.get("error"):
            return "{}: {}".format(entry["name"], entry["error"])
    for entry in report:
        if "skipped" in entry:
            return "{}: {}".format(entry["name"], entry["skipped"])
    empty = [entry["name"] for entry in report if "seconds" in entry]
    if empty:  # asked and answered, with nothing: its own settings (providers, quality filter) rule them out
        return "{} found no streams for this {}: check {} Configure settings".format(
            " and ".join(empty), kind, "their" if len(empty) > 1 else "its")
    return "No streams found for this {}".format(kind)


def list_folder(path):
    """A folder's items, listed on this thread (Files.GetDirectory)."""
    request = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
               "params": {"directory": path, "media": "video", "properties": ["title", "year"],
                          "limits": {"start": 0, "end": 50}}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {}).get("files") or []
    except ValueError:
        return []


def has_addon(addon):
    return bool(addon) and xbmc.getCondVisibility("System.HasAddon({})".format(addon))


def player_offers(sources, kind, values, timeout):
    """{source index: (offers, report entry)} for the player sources, each listed on its own
    thread (a folder player's listing can take a while), at most timeout seconds."""
    results, threads = {}, []

    def ask(n, source):
        results[n] = players.offers(source, kind, values, has_addon, list_folder)
    for n, source in enumerate(sources):
        if "player" in source:
            thread = threading.Thread(target=ask, args=(n, source))
            thread.daemon = True
            thread.start()
            threads.append(thread)
    return results, threads


def list_item(kind, values, path):
    title = values.get("title") or values.get("showname") or ""
    item = xbmcgui.ListItem(title, path=path, offscreen=True)
    tag = item.getVideoInfoTag()
    tag.setMediaType(kind)
    tag.setTitle(title)
    if kind == "episode":
        tag.setTvShowTitle(values.get("showname") or "")
        if values.get("season", "").isdigit() and values.get("episode", "").isdigit():
            tag.setSeason(int(values["season"]))
            tag.setEpisode(int(values["episode"]))
    else:
        ids = {k: values[k] for k in ("tmdb", "imdb", "tvdb") if values.get(k)}
        if ids:
            tag.setUniqueIDs(ids, "imdb" if "imdb" in ids else next(iter(ids)))
    item.setArt({k: values[k] for k in ("poster", "fanart") if values.get(k)})
    return item


def library_file(kind, values):
    """The title's file in the Kodi library (matched by its ids), or "". Add-on paths (a .strm
    to a plugin) don't count: they'd need the lookup anyway."""
    ids = {values.get(k) for k in ("tmdb", "imdb", "tvdb") if values.get(k)}

    def rpc(method, params):
        request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        try:
            return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result") or {}
        except ValueError:
            return {}

    def own(entry):
        return bool(ids & {str(v) for v in (entry.get("uniqueid") or {}).values()})

    if kind == "movie":
        found = [m for m in rpc("VideoLibrary.GetMovies", {"properties": ["uniqueid", "file"]}).get("movies") or [] if own(m)]
    else:
        shows = [t for t in rpc("VideoLibrary.GetTVShows", {"properties": ["uniqueid"]}).get("tvshows") or [] if own(t)]
        found = []
        if shows and values.get("season", "").isdigit() and values.get("episode", "").isdigit():
            found = rpc("VideoLibrary.GetEpisodes", {
                "tvshowid": shows[0]["tvshowid"], "season": int(values["season"]), "properties": ["episode", "file"]
            }).get("episodes") or []
            found = [e for e in found if e.get("episode") == int(values["episode"])]
    files = [f.get("file") or "" for f in found]
    return next((f for f in files if f and not f.startswith("plugin://")), "")


def local_copy(kind, values):
    """(path, what) for a copy that needs no lookup, or None: downloaded, in the library, or
    being downloaded (the link it's coming from)."""
    entry = downloads.find(data_dir(), kind, values)
    if entry and entry.get("status") == "done" and xbmcvfs.exists(entry.get("file") or ""):
        return entry["file"], "downloaded"
    found = library_file(kind, values)
    if found:
        return found, "in the library"
    if entry and entry.get("status") in ("downloading", "client") and entry.get("url"):
        return entry["url"], "downloading"  # client: a torrent add-on has it, its play path streams it
    return None


def find_offers(kind, values):
    """(offered, None) or ([], why nothing): every source asked at once, the playable offers
    [(source name, stream, (path, how))] in the sources' order."""
    folder = data_dir()
    sources = store.read_sources(folder)
    if not sources:
        return [], "No sources yet: add some in Ultra Player > Manage sources"
    resolve, timeout = settings()
    addons = [i for i, s in enumerate(sources) if "manifest" in s]
    found = streams.manifests([sources[i] for i in addons], store.manifest_cache(folder))
    installed = {a for a in ("plugin.video.youtube",) + tuple(t[0] for t in streams.TORRENT_PLAYERS)
                 if xbmc.getCondVisibility("System.HasAddon({})".format(a))}
    from_players, threads = player_offers(sources, kind, values, timeout)
    got, addon_report = streams.gather([sources[i] for i in addons], found, kind, values, timeout)
    for thread in threads:
        thread.join(timeout + 1)
    # Offers and report in the sources' order: each add-on's streams, each player's paths.
    by_source = {}
    for n, source_name, stream in got:
        by_source.setdefault(addons[n], []).append((source_name, stream))
    report = [None] * len(sources)
    for n, entry in zip(addons, addon_report):
        report[n] = entry
    offered, dropped = [], {}
    for n, source in enumerate(sources):
        if "player" in source:
            offers, entry = from_players.get(n) or ([], {"name": source.get("name") or "Player", "url": "",
                                                         "streams": 0, "error": "timed out"})
            report[n] = entry
            offered.extend((entry["name"], stream, target) for stream, target in offers)
            continue
        for source_name, stream in by_source.get(n, []):
            target, why = streams.classify(stream, installed)
            if target:
                offered.append((source_name, stream, target))
            else:
                dropped.setdefault(source_name, {}).setdefault(why, 0)
                dropped[source_name][why] += 1
    report = [entry for entry in report if entry]
    log("{} {}: {} sources, resolve {}, timeout {}s, players installed: {}".format(
        kind, streams.item_ids(kind, values), len(sources), resolve, timeout, ", ".join(sorted(installed)) or "none"))
    for entry in report:
        state = ("skipped: " + entry["skipped"]) if "skipped" in entry else (
            "{} streams in {}s".format(entry["streams"], entry["seconds"]) + (", " + entry["error"] if entry.get("error") else ""))
        why = ", ".join("{} {}".format(n, streams.DROPPED[k]) for k, n in sorted(dropped.get(entry["name"], {}).items()))
        log("  {}: {} - {}{}".format(entry["name"], entry["url"], state, "; left out: " + why if why else ""))
    log("{} playable".format(len(offered)))
    return offered, None if offered else no_streams_reason(kind, report, dropped)


def skin_cancelled():
    """The skin's loading screen was left with Back while the sources were asked."""
    return xbmcgui.Window(10000).getProperty(SKIN_CANCEL) == "1"


def skin_sources():
    """The current skin's own source list window file, or None."""
    for folder in ("1080i", "720p", "xml"):
        if xbmcvfs.exists(xbmcvfs.translatePath("special://skin/{}/{}".format(folder, SKIN_SOURCES))):
            return SKIN_SOURCES
    return None


class SourcesWindow(xbmcgui.WindowXMLDialog):
    """The skin's source list: the items in list SKIN_SOURCES_LIST; choice the picked index or -1."""

    def __init__(self, *args, **kwargs):
        self.items = kwargs.pop("items", [])
        self.choice = -1

    def onInit(self):
        control = self.getControl(SKIN_SOURCES_LIST)
        control.reset()
        control.addItems(self.items)
        self.setFocusId(SKIN_SOURCES_LIST)

    def onClick(self, control_id):
        if control_id == SKIN_SOURCES_LIST:
            self.choice = self.getControl(SKIN_SOURCES_LIST).getSelectedPosition()
            self.close()


def choose_offer(offered, values, heading="Sources"):
    """The offer to use: the first (resolve "auto") or the one picked; None if cancelled."""
    if settings()[0] != "choose":
        return offered[0]
    home = xbmcgui.Window(10000)
    home.setProperty(STATE, "choosing")
    window_file = skin_sources()
    items = []
    for source_name, stream, _ in offered:
        label, details = streams.describe(stream)
        if window_file:
            item = xbmcgui.ListItem(label, details, offscreen=True)
            item.setProperty("source", source_name)
        else:
            item = xbmcgui.ListItem("[{}]  {}".format(source_name, label), details, offscreen=True)
        items.append(item)
    if window_file:
        window = SourcesWindow(window_file, xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"), "Default", "1080i", items=items)
        window.doModal()
        choice = window.choice
        del window
    else:
        choice = xbmcgui.Dialog().select("{}: {}".format(heading, values.get("title") or values.get("showname")), items,
                                         useDetails=True)
    if choice >= 0:
        home.clearProperty(STATE)
        return offered[choice]
    home.setProperty(STATE, "cancelled")
    return None


def hand_over(handle, kind, values, path, how="url"):
    xbmcgui.Window(10000).setProperty(STATE, "handing")
    if how == "run":  # a player add-on that starts the video itself
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        xbmc.executebuiltin('RunPlugin("{}")'.format(path))
        return
    item = list_item(kind, values, path)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, item)  # a player's plugin path: Kodi resolves it in turn
    else:
        xbmc.Player().play(path, item)


def play(handle, params):
    home = xbmcgui.Window(10000)
    home.clearProperty(STATE)
    home.clearProperty(MESSAGE)
    kind, values = values_from(params)
    if not (values["tmdb"] or values["imdb"]):
        fail(handle, "No TMDb or IMDb id for this {}".format(kind))
        return
    if local_first():
        local = local_copy(kind, values)
        if local:
            log("{} {}: playing it {}, no lookup: {}".format(kind, streams.item_ids(kind, values), local[1],
                                                             streams.redact(local[0].split("|")[0]) if "://" in local[0] else local[0]))
            hand_over(handle, kind, values, local[0])
            return
    offered, why = find_offers(kind, values)
    if skin_cancelled():
        log("{} {}: the loading screen was left, not playing".format(kind, streams.item_ids(kind, values)))
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        return
    if not offered:
        fail(handle, why)
        return
    chosen = choose_offer(offered, values)
    if chosen is None:
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        return
    _, stream, (path, how) = chosen
    label, details = streams.describe(stream)
    log("{} through {} ({}): {} {}".format(kind, streams.redact(path.split("|")[0]) if how == "url" else path.split("?")[0],
                                           how, label, details))
    hand_over(handle, kind, values, path, how)
