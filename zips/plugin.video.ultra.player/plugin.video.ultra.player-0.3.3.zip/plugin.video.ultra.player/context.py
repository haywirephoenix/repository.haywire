"""The Download context menu item (addon.xml kodi.context.item): the focused movie or episode's
values, as a skin's play URL gives them, then resources/lib/download.py. An episode's ids are
its show's (Floppy's tvshow.* properties, else the item's own)."""
import os
import sys

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import download  # noqa: E402


def info(name):
    return xbmc.getInfoLabel("ListItem.{}".format(name))


def values():
    kind = "episode" if info("DBType") == "episode" else "movie"
    out = {k: info("UniqueID({})".format(k)) for k in ("tmdb", "imdb", "tvdb")}
    if kind == "episode":
        for k in ("tmdb", "imdb", "tvdb"):
            out[k] = info("Property(tvshow.{}_id)".format(k)) or out[k]
        out.update(season=info("Season"), episode=info("Episode"), showname=info("TVShowTitle"))
    out.update(title=info("Title") or info("Label"), year=info("Year"),
               poster=info("Art(poster)") or info("Art(tvshow.poster)"), fanart=info("Art(fanart)"))
    return kind, out


if __name__ == "__main__":
    download.run(*values())
