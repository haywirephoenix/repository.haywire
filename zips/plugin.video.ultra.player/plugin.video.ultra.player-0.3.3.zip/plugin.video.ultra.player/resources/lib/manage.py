"""Manage sources (plugin://plugin.video.ultra.player/sources): the sources list, with Add,
and for each source Configure (when its manifest says it can be), Change link, Reload its
manifest, Move up / down and Remove. Saved in store.py's sources.json as each change is made.

Adding or configuring takes an add-on link (manifest.json, stremio:// or a Stremio Web link):
typed or pasted here, or sent from a phone or computer on the network (configure.receive),
with the add-on's configure page opened on this device first where it has a browser.
A source can also be a player add-on: a TMDb Helper player file (players.py), picked from the
player folders (PLAYER_FOLDERS) or browsed for; its contents are kept with the source, and
Reload its player file reads it again.

Without Torrest, the list ends with a line that installs it (Ultra Player works best with it:
Download, replaying what it kept, its progress on the skin's loading screen). pick_torrent_player
(Ultra Player settings > Torrent player) picks the add-on that plays torrent streams
(torrents.py), with the same line.
"""
import glob
import json
import os
import sys
from urllib.parse import urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import configure  # noqa: E402
import player  # noqa: E402
import players  # noqa: E402
import store  # noqa: E402
import streams  # noqa: E402
import torrents  # noqa: E402

GET_TORRENT_PLAYER = "[B]Ultra Player works best with {} - download[/B]".format(torrents.RECOMMENDED_NAME)

HEADING = "Manage sources"
# Where player files usually are: the users', then the add-ons' own (read only).
PLAYER_FOLDERS = (
    "special://profile/addon_data/plugin.video.themoviedb.helper/players/",
    "special://profile/addon_data/plugin.video.tmdb.bingie.helper/players/",
    "special://profile/addon_data/skin.ultra/players/",
    "special://home/addons/plugin.video.themoviedb.helper/resources/players/",
    "special://home/addons/plugin.video.tmdb.bingie.helper/resources/players/",
)


def notify(message, error=False):
    xbmcgui.Dialog().notification("Ultra Player", message,
                                  xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 5000)


def fetch_source(link, folder):
    """{"name", "manifest"} for an add-on link (its manifest fetched and cached), or None
    after saying what's wrong."""
    url = streams.manifest_link(link)
    if not url.startswith(("https://", "http://")) or not url.split("?", 1)[0].endswith("manifest.json"):
        notify("Not an add-on link: it ends in manifest.json", error=True)
        return None
    try:
        manifest = streams.fetch_json(url)
    except (OSError, ValueError) as e:
        notify("Couldn't load the add-on: {}".format(e), error=True)
        return None
    problem = streams.check_manifest(manifest)
    if problem:
        notify(problem, error=True)
        return None
    cache = streams.read_cache(store.manifest_cache(folder))
    cache[url] = manifest
    os.makedirs(folder, exist_ok=True)
    streams.write_cache(store.manifest_cache(folder), cache)
    return {"name": str(manifest.get("name") or manifest["id"]), "manifest": url}


def read_player(path):
    """(player, problem) for a player file."""
    try:
        with open(path, encoding="utf-8") as f:
            found = json.load(f)
    except (OSError, ValueError) as e:
        return None, "Couldn't read {}: {}".format(os.path.basename(path), e)
    return found, players.check(found)


def player_source(found, path):
    return {"name": str(found.get("name") or found["plugin"]), "player": found, "file": path}


def pick_player():
    """A player source picked from the player folders, or browsed for; None if cancelled."""
    found, seen = [], set()
    for folder in PLAYER_FOLDERS:
        for path in sorted(glob.glob(os.path.join(xbmcvfs.translatePath(folder), "*.json"))):
            key = os.path.basename(path).lower()
            if key in seen:
                continue  # the users' copy wins
            entry, problem = read_player(path)
            if problem:
                continue
            seen.add(key)
            found.append((entry, path))
    found.sort(key=lambda p: str(p[0].get("name") or "").lower())
    dialog = xbmcgui.Dialog()
    items = []
    for entry, path in found:
        installed = xbmc.getCondVisibility("System.HasAddon({})".format(entry["plugin"]))
        items.append(xbmcgui.ListItem(str(entry.get("name") or entry["plugin"]), "{}{}  ({})".format(
            entry["plugin"], "" if installed else ", not installed", os.path.basename(path)), offscreen=True))
    items.append(xbmcgui.ListItem("[B]Browse for a player file...[/B]", "A TMDb Helper player .json", offscreen=True))
    choice = dialog.select("Add a player add-on", items, useDetails=True)
    if choice < 0:
        return None
    if choice < len(found):
        return player_source(*found[choice])
    path = dialog.browse(1, "Player file", "files", ".json")
    if not path:
        return None
    entry, problem = read_player(xbmcvfs.translatePath(path))
    if problem:
        notify(problem, error=True)
        return None
    return player_source(entry, path)


def ask_link(heading, name, configure_url=None, current=""):
    """A new add-on link: typed or pasted here, or sent from another device's browser (with the
    configure page, when there is one, opened here first if this device has a browser)."""
    dialog = xbmcgui.Dialog()
    options = []
    if configure_url and configure.can_open_here():
        options.append(("Open the configure page here, then paste the link", "here"))
    options.append(("Use a phone or computer on this network", "device"))
    options.append(("Type or paste the link here", "type"))
    choice = dialog.select(heading, [o[0] for o in options])
    if choice < 0:
        return None
    how = options[choice][1]
    if how == "device":
        return configure.receive(heading, name, configure_url)
    if how == "here" and not configure.open_here(configure_url):
        notify("Couldn't open a browser here", error=True)
        return None
    return dialog.input("{}: install link (manifest.json or stremio://)".format(name), current) or None


def add_source(folder):
    """A new source of either kind, or None if cancelled."""
    kinds = [xbmcgui.ListItem("Stremio or Nuvio add-on", "Its install link (manifest.json or stremio://)", offscreen=True),
             xbmcgui.ListItem("Player add-on", "Another Kodi add-on, through a TMDb Helper player file", offscreen=True)]
    kind = xbmcgui.Dialog().select("Add a source", kinds, useDetails=True)
    if kind == 0:
        link = ask_link("Add a source", "New source")
        return fetch_source(link, folder) if link else None
    if kind == 1:
        return pick_player()
    return None


def install_recommended():
    """Kodi's install of Torrest (from a repository that has it: haywire's)."""
    xbmc.executebuiltin("InstallAddon({})".format(torrents.RECOMMENDED), True)


def pick_torrent_player():
    """Torrent player (the torrent_player setting): Auto, or one of the torrent player files
    whose add-on is installed; without Torrest, a line that installs it."""
    addon = xbmcaddon.Addon(player.ADDON_ID)
    current = addon.getSetting("torrent_player") or torrents.AUTO
    found = torrents.load(player.torrent_folders())
    auto = torrents.choose(found, torrents.AUTO, player.has_addon)
    options = [(torrents.AUTO, "Auto", "Uses {}".format(torrents.name(auto)) if auto else "No torrent player installed")]
    options += [(plugin, torrents.name(p), plugin) for plugin, p in sorted(found.items()) if player.has_addon(plugin)]
    get = not player.has_addon(torrents.RECOMMENDED)
    items = [xbmcgui.ListItem(label, detail, offscreen=True) for _, label, detail in options]
    if get:
        items.append(xbmcgui.ListItem(GET_TORRENT_PLAYER, "Plays torrent streams, downloads them, and shows their "
                                      "progress on the loading screen", offscreen=True))
    values = [value for value, _, _ in options]
    choice = xbmcgui.Dialog().select("Torrent player", items, preselect=values.index(current) if current in values else 0,
                                     useDetails=True)
    if choice < 0:
        return
    if get and choice == len(options):
        install_recommended()
        return
    addon.setSetting("torrent_player", values[choice])
    chosen = torrents.choose(found, values[choice], player.has_addon)
    notify("Torrents play with {}".format(torrents.name(chosen)) if chosen else "No torrent player installed")


def run():
    dialog = xbmcgui.Dialog()
    folder = player.data_dir()
    while True:
        sources = store.read_sources(folder)
        cache = streams.read_cache(store.manifest_cache(folder))
        items = []
        for n, source in enumerate(sources):
            if "player" in source:
                item = xbmcgui.ListItem("{}. {}".format(n + 1, source.get("name") or "?"), offscreen=True)
                item.setLabel2("Player add-on: {}".format(source["player"].get("plugin", "")))
                items.append(item)
                continue
            manifest = cache.get(source["manifest"]) or {}
            hints = manifest.get("behaviorHints") or {}
            item = xbmcgui.ListItem("{}. {}".format(n + 1, source.get("name") or manifest.get("name") or "?"), offscreen=True)
            item.setLabel2(urlsplit(source["manifest"]).netloc + ("  (configurable)" if hints.get("configurable") else ""))
            items.append(item)
        items.append(xbmcgui.ListItem("[B]Add a source...[/B]", "A Stremio or Nuvio add-on, or a player add-on", offscreen=True))
        get = not player.has_addon(torrents.RECOMMENDED)
        if get:
            items.append(xbmcgui.ListItem(GET_TORRENT_PLAYER, "Plays torrent streams, downloads them, and shows their "
                                          "progress on the loading screen", offscreen=True))
        choice = dialog.select(HEADING, items, useDetails=True)
        if choice < 0:
            return
        if get and choice == len(sources) + 1:
            install_recommended()
            continue
        if choice == len(sources):
            source = add_source(folder)
            if source:
                store.write_sources(folder, sources + [source])
            continue

        n, source = choice, sources[choice]
        name = source.get("name") or "Source"
        if "player" in source:
            actions = ["Reload its player file"] if source.get("file") else []
        else:
            configurable = ((cache.get(source["manifest"]) or {}).get("behaviorHints") or {}).get("configurable")
            actions = (["Configure..."] if configurable else []) + ["Change link...", "Reload its manifest"]
        actions += (["Move up"] if n > 0 else []) + (["Move down"] if n < len(sources) - 1 else []) + ["Remove"]
        pick = dialog.select(name, actions)
        if pick < 0:
            continue
        action = actions[pick]
        if action in ("Configure...", "Change link..."):
            link = ask_link(name, name, streams.configure_url(source["manifest"]) if action == "Configure..." else None,
                            source["manifest"])
            replaced = fetch_source(link, folder) if link else None
            if replaced:
                sources[n] = replaced
        elif action == "Reload its player file":
            entry, problem = read_player(xbmcvfs.translatePath(source["file"]))
            if problem:
                notify(problem, error=True)
                continue
            sources[n] = player_source(entry, source["file"])
        elif action == "Reload its manifest":
            replaced = fetch_source(source["manifest"], folder)
            if replaced:
                sources[n] = replaced
        elif action == "Move up":
            sources.insert(n - 1, sources.pop(n))
        elif action == "Move down":
            sources.insert(n + 1, sources.pop(n))
        elif dialog.yesno(HEADING, "Remove {}?".format(name)):
            sources.pop(n)
        else:
            continue
        store.write_sources(folder, sources)
