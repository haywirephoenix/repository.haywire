"""A title's trailer as a direct video link, from IMDb (its public GraphQL API).

    plugin://plugin.video.ultra.player/trailer?imdb=tt0944947[&quality=1080]

lists the trailer as one playable item whose path is the MP4 itself (an empty folder when IMDb
has none). Listing a folder runs on the caller's thread, so a skin that lists it from a script
(skin.ultra's background trailer, as a trailer source) only leaves Kodi opening the video;
playing an add-on link instead has Kodi's main thread wait on the add-on, under its busy
dialog, which takes key presses meanwhile.
"""
import json
import re
import urllib.request

API = "https://graphql.prod.api.imdb.a2z.com/"
HEADERS = {"Content-Type": "application/json", "Referer": "https://www.imdb.com/", "Origin": "https://www.imdb.com",
           "User-Agent": "Mozilla/5.0"}
QUERY = ("query ($id: ID!) { title(id: $id) { titleText { text } latestTrailer { name { value } runtime { value } "
         "thumbnail { url } playbackURLs { displayName { value } videoMimeType url } } } }")
TIMEOUT = 10
IMDB_ID = re.compile(r"^tt\d+$")


def fetch(imdb_id, timeout=TIMEOUT):
    body = json.dumps({"query": QUERY, "variables": {"id": imdb_id}}).encode("utf-8")
    request = urllib.request.Request(API, data=body, headers=HEADERS)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def pick(data, quality=1080):
    """{title, name, url, height, runtime, thumb} for the best MP4 at or under quality (else
    the smallest one), or None."""
    title = ((data or {}).get("data") or {}).get("title") or {}
    trailer = title.get("latestTrailer") or {}
    mp4s = []
    for entry in trailer.get("playbackURLs") or []:
        label = ((entry.get("displayName") or {}).get("value") or "")
        m = re.match(r"^(\d+)p$", label)
        if entry.get("videoMimeType") == "MP4" and entry.get("url"):
            mp4s.append((int(m.group(1)) if m else 360, entry["url"]))  # "SD" is 360p or so
    if not mp4s:
        return None
    fitting = [v for v in mp4s if v[0] <= quality]
    height, url = max(fitting) if fitting else min(mp4s)
    return {"title": (title.get("titleText") or {}).get("text") or "",
            "name": (trailer.get("name") or {}).get("value") or "",
            "url": url, "height": height,
            "runtime": (trailer.get("runtime") or {}).get("value") or 0,
            "thumb": (trailer.get("thumbnail") or {}).get("url") or ""}


def find(imdb_id, quality=1080):
    """The trailer for imdb_id, or None (no id, no trailer, or IMDb didn't answer)."""
    if not IMDB_ID.match(imdb_id or ""):
        return None
    try:
        return pick(fetch(imdb_id), quality)
    except (OSError, ValueError):
        return None
