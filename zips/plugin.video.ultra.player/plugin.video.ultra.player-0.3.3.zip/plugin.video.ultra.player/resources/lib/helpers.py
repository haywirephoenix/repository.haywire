"""Ultra Player's player file for TMDb Helper (and its Bingie fork), installed into their own
players folders: they only read player files from there, not from other add-ons.

    install(force=False)   copies resources/players/ultra.player.json into each installed
                           helper's addon_data/<id>/players/; without force only where it's
                           missing, so a copy the user changed stays. Returns the helpers written.
"""
import os
import shutil

PLAYER_FILE = "ultra.player.json"
HELPERS = (
    ("plugin.video.themoviedb.helper", "TMDb Helper"),
    ("plugin.video.tmdb.bingie.helper", "TMDb Bingie Helper"),
)
SOURCE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "players", PLAYER_FILE)


def targets(profile_dir, installed):
    """{helper name: its players/ultra.player.json} for the installed helpers."""
    return {name: os.path.join(profile_dir, "addon_data", addon, "players", PLAYER_FILE)
            for addon, name in HELPERS if addon in installed}


def install_into(profile_dir, installed, force=False):
    """The pure part of install(): profile_dir is Kodi's userdata folder."""
    written = []
    for name, path in targets(profile_dir, installed).items():
        if os.path.exists(path) and not force:
            continue
        os.makedirs(os.path.dirname(path), exist_ok=True)
        shutil.copyfile(SOURCE, path)
        written.append(name)
    return written


def install(force=False):
    import xbmc
    import xbmcvfs
    installed = {addon for addon, _ in HELPERS if xbmc.getCondVisibility("System.HasAddon({})".format(addon))}
    written = install_into(xbmcvfs.translatePath("special://profile/"), installed, force)
    if written:
        xbmc.log("[plugin.video.ultra.player] player file installed for {}".format(", ".join(written)), xbmc.LOGINFO)
    return written, [name for addon, name in HELPERS if addon in installed]
