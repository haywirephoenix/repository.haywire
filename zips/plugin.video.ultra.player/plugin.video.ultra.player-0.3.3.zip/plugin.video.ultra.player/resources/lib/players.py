"""Player sources: another Kodi add-on, through a TMDb Helper player file (its format, as Floppy
and skin.ultra read it). A source {"name", "player": {...the file...}, "file": where it came from}.

A player's "play_movie" / "play_episode" is either
- a path: filled in (fill) and handed over: resolvable ones through setResolvedUrl, the others
  (is_resolvable "false": the add-on starts the video itself) run with RunPlugin; or
- [folder path, {rules}]: the folder is listed and each playable item whose fields match every
  rule (a regex with the item's values in; "title" is matched against the label) is offered.
"assert": {"play_movie": [fields]} skips it for an item missing any of those values.

No Kodi modules here (tests/test_players.py): has_addon and list_folder are passed in.
"""
import re
from urllib.parse import quote, quote_plus

ULTRA_PLAYER = "plugin.video.ultra.player"
# The values a play URL gives (player.values_from) and TMDb Helper's other names for some.
ALIASES = {"tvshowtitle": "showname", "clearname": "showname", "showyear": "year"}
ENCODINGS = {
    "": lambda v: v,
    "_url": quote,
    "_url+": quote_plus,
    "_+": lambda v: v.replace(" ", "+"),
    "_-": lambda v: v.replace(" ", "-"),
    "_escaped": lambda v: quote(quote(v)),
    "_escaped+": lambda v: quote(quote_plus(v)),
}
PLACEHOLDER = re.compile(r"\{([a-z_]+?)(" + "|".join(re.escape(s) for s in sorted(ENCODINGS, key=len, reverse=True) if s)
                         + r")?\}")


def item_values(kind, values):
    """The play URL's values as player files name them: an episode's {title} is the episode's,
    {showname} the show's; {id} TMDb Helper's (the TMDb id); {name} "Title (Year)"."""
    out = dict(values)
    out["id"] = values.get("tmdb", "")
    if kind == "episode":
        out["eptitle"] = values.get("title", "")
    title = out.get("title", "")
    out["name"] = "{} ({})".format(title, out["year"]) if out.get("year") and title else title
    return out


def fill(path, values):
    """path with the {placeholders} filled in ({title_url}: URL-encoded); unknown ones empty."""
    def put(m):
        name = ALIASES.get(m.group(1), m.group(1))
        return ENCODINGS[m.group(2) or ""](str(values.get(name) or ""))
    return PLACEHOLDER.sub(put, path)


def check(player):
    """Why a player file can't be a source, or None."""
    if not isinstance(player, dict):
        return "Not a player file"
    if not isinstance(player.get("plugin"), str) or not player["plugin"]:
        return "The player file names no add-on (\"plugin\")"
    if player["plugin"] == ULTRA_PLAYER:
        return "That's Ultra Player's own player file"
    if not any(spec(player, kind) for kind in ("movie", "episode")):
        return "The player file has no play_movie or play_episode"
    return None


def spec(player, kind):
    """(path, rules or None) for play_<kind>, or None."""
    value = player.get("play_" + kind) if isinstance(player, dict) else None
    if isinstance(value, list) and value and isinstance(value[0], str):
        return value[0], value[1] if len(value) > 1 and isinstance(value[1], dict) else {}
    if isinstance(value, str) and value:
        return value, None
    return None


def fill_rule(pattern, values):
    """A rule's regex with the values in, escaped, so a title's brackets match literally."""
    def put(m):
        name = ALIASES.get(m.group(1), m.group(1))
        return re.escape(ENCODINGS[m.group(2) or ""](str(values.get(name) or "")))
    return PLACEHOLDER.sub(put, pattern)


def matches(entry, rules, values):
    for key, pattern in rules.items():
        if key == "dialog":
            continue
        text = entry.get(key) if key != "title" else entry.get("title") or entry.get("label")
        try:
            if not re.search(fill_rule(str(pattern), values), str(text or ""), re.I):
                return False
        except re.error:
            return False
    return True


def offers(source, kind, values, has_addon, list_folder):
    """([(stream, (path, how))], report entry) for a player source. how: "plugin" (handed to Kodi
    to resolve) or "run" (RunPlugin). stream: {"name", "title"} for the sources list.
    list_folder(path) -> [{"label", "file", "filetype", ...}]."""
    player = source.get("player") or {}
    name = source.get("name") or player.get("name") or "Player"
    entry = {"name": name, "url": player.get("plugin", ""), "streams": 0}
    found = spec(player, kind)
    if not found:
        entry["skipped"] = "no play_{} in its player file".format(kind)
        return [], entry
    if not has_addon(player.get("plugin", "")):
        entry["skipped"] = "{} isn't installed".format(player.get("plugin"))
        return [], entry
    values = item_values(kind, values)
    asserted = (player.get("assert") or {}).get("play_" + kind) if isinstance(player.get("assert"), dict) else None
    missing = [f for f in asserted or [] if not values.get(ALIASES.get(f, f))]
    if missing:
        entry["skipped"] = "no {} for this {}".format(", ".join(missing), kind)
        return [], entry
    path, rules = found
    url = fill(path, values)
    how = "run" if str(player.get("is_resolvable", "true")).lower() == "false" else "plugin"
    if rules is None:
        entry["streams"] = 1
        return [({"name": "Play through {}".format(name), "title": player.get("plugin", "")}, (url, how))], entry
    items = [f for f in list_folder(url) or [] if f.get("filetype") != "directory" and f.get("file")
             and matches(f, rules, values)]
    entry["streams"] = len(items)
    return [({"name": name, "title": f.get("label") or f["file"]}, (f["file"], "plugin")) for f in items], entry
