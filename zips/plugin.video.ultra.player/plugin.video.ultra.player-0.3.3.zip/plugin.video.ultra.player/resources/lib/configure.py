"""Configuring an extra source (a Stremio-protocol add-on; streams.py) from Kodi, which has no
web browser. Stremio's Configure opens <base>/configure; the page's Install button then gives a
new manifest link with the chosen settings in it. Two ways to get that link back:

- open_here(url): this device's own browser (Android's VIEW intent, Windows' default browser,
  or Python's webbrowser elsewhere); then paste the new link in Kodi's keyboard.
- receive(): a page on the home network (a random port and token, only while the dialog is
  up) that another device opens: it links to the configure page and takes the new link back.
  Its address is shown as text. (A QR code for it is a later idea.)
"""
import html
import os
import secrets
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Ultra: {name}</title>
<style>body{{font-family:system-ui,sans-serif;background:#111;color:#eee;margin:0;padding:24px;max-width:640px}}
a,button{{display:block;margin:16px 0;padding:14px;border-radius:8px;background:#e50914;color:#fff;
text-align:center;text-decoration:none;border:0;font-size:16px;width:100%}}
textarea{{width:100%;box-sizing:border-box;min-height:96px;font-size:15px;border-radius:8px;padding:10px}}
p{{color:#aaa;line-height:1.5}}</style></head><body>
<h2>{name}</h2>{configure}
<form method="post"><p>{prompt}</p>
<textarea name="link" placeholder="https://.../manifest.json or stremio://..." required></textarea>
<button type="submit">Send to Kodi</button></form></body></html>"""
CONFIGURE_PART = """<p>1. Open the add-on's configure page, choose its settings, then copy its install link
(long-press Install, or its Copy link button).</p><a href="{url}" target="_blank" rel="noopener">Open the configure page</a>
<p>2. Paste the link here.</p>"""
DONE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
</head><body style="font-family:system-ui;background:#111;color:#eee;padding:24px"><h2>Sent to Kodi</h2>
<p>You can close this page.</p></body></html>"""


def open_here(url):
    """Opens url in this device's browser; False where there's no way to."""
    import xbmc
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","{}")'.format(url))
        return True
    try:
        if sys.platform.startswith("win"):
            os.startfile(url)  # noqa: S606 (the user's own browser)
            return True
        import webbrowser
        return webbrowser.open(url)
    except (OSError, AttributeError):
        return False


def can_open_here():
    import xbmc
    return (xbmc.getCondVisibility("System.Platform.Android") or xbmc.getCondVisibility("System.Platform.Windows")
            or xbmc.getCondVisibility("System.Platform.OSX") or xbmc.getCondVisibility("System.Platform.Linux"))


class _Drop(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, token, page):
        super().__init__(("0.0.0.0", 0), _Handler)
        self.token, self.page, self.link = token, page, None


class _Handler(BaseHTTPRequestHandler):
    def _send(self, code, body):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _ours(self):
        return self.path.split("?", 1)[0].strip("/") == self.server.token

    def do_GET(self):  # noqa: N802
        self._send(200, self.server.page) if self._ours() else self._send(404, "")

    def do_POST(self):  # noqa: N802
        if not self._ours():
            self._send(404, "")
            return
        length = min(int(self.headers.get("Content-Length") or 0), 16384)
        form = parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
        link = (form.get("link") or [""])[0].strip()
        if link:
            self.server.link = link
        self._send(200, DONE)

    def log_message(self, *args):
        pass


def receive(heading, name, configure_url=None):
    """The link another device sends from the page (None if cancelled or after 15 minutes)."""
    import xbmc
    import xbmcgui
    token = secrets.token_urlsafe(6)
    configure = CONFIGURE_PART.format(url=html.escape(configure_url, quote=True)) if configure_url else ""
    prompt = "Paste the add-on's new install link." if configure_url else "Paste the add-on's link (manifest.json or stremio://)."
    server = _Drop(token, PAGE.format(name=html.escape(name), configure=configure, prompt=prompt))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    address = "http://{}:{}/{}".format(xbmc.getIPAddress() or "this-device", server.server_address[1], token)
    progress = xbmcgui.DialogProgress()
    progress.create(heading, "On a phone or computer on this network, open:[CR][B]{}[/B]".format(address))
    try:
        for tick in range(15 * 60 * 2):
            if server.link or progress.iscanceled():
                break
            progress.update(100 - int(tick * 100 / (15 * 60 * 2)))
            xbmc.sleep(500)
        return server.link
    finally:
        progress.close()
        server.shutdown()
        server.server_close()
