"""At login: install Ultra Player's TMDb Helper player file where it's missing (helpers.py),
so TMDb Helper lists Ultra Player without Ultra Player having been opened first; and mark
downloads Kodi closed on as stopped, so Download carries them on. Then exits."""
import os
import sys

import xbmcvfs

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import downloads  # noqa: E402
import helpers  # noqa: E402

DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ultra.player/")

if __name__ == "__main__":
    try:
        helpers.install()
    except OSError:
        pass
    try:
        items = downloads.read_index(DATA)
        if any(e.get("status") == "downloading" for e in items.values()):
            for entry in items.values():
                if entry.get("status") == "downloading":
                    entry["status"] = "stopped"
            downloads.write_index(DATA, items)
    except OSError:
        pass
