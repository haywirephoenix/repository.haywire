# Ultra Player

A Kodi video add-on that plays movies and episodes from Stremio-protocol add-ons (Stremio's and
Nuvio's: Torrentio, AIOStreams, ...). Give it a title's ids and it asks every source for streams
at once, then plays the first playable one or the one you pick.

## Playing

    plugin://plugin.video.ultra.player/play?kind=movie&tmdb=27205&imdb=tt1375666&title=Inception&year=2010
    plugin://plugin.video.ultra.player/play?kind=episode&tmdb=1399&imdb=tt0944947&season=1&episode=2&showname=Game%20of%20Thrones

`kind`, `tmdb` / `imdb` / `tvdb` (an episode's are its show's), `season`, `episode`, `title`
(the movie's or the episode's), `showname`, `year`, `poster`, `fanart`. It resolves like any
playable link (setResolvedUrl), so skin.ultra, Floppy (Plugin path), TMDb Helper and other
add-ons can use it.

TMDb Helper (and TMDb Bingie Helper) only read player files from their own `players` folder, so
Ultra Player installs `resources/players/ultra.player.json` there itself: at login and on any run
where it's missing (a copy you changed is left alone), and over an older copy from its menu or
settings (Install TMDb Helper player).

Streams: direct links play as they are (with any headers the source asks for); YouTube ones
through the YouTube add-on; torrents through a torrent player, or play direct once the source
has a debrid service set in its Configure page.

## Torrent players

Torrent streams play through a torrent add-on, described by a torrent player file: JSON in the
player files' style, with `plugin`, a `play_magnet` path (`{magnet_url}`, `{magnet}`,
`{info_hash}`), an `index` added when the stream names its file (`{index}`), and optionally a
`download_magnet` path (Download) and a `torrents` folder that lists the torrents it keeps (a
title streamed before plays again from what it kept, without asking the sources). Ultra Player
ships Torrest's (`resources/torrent_players/torrest.json`); others go in its profile's
`torrent_players` folder. Settings > Torrent player picks one; Auto uses Torrest when it's
installed. Ultra Player works best with Torrest (Download, replaying what it kept, its progress
on skin.ultra's loading screen): without it, Manage sources and Torrent player offer to install
it. `extras/torrent_players` holds files for other torrent add-ons (Elementum), kept out of the
add-on's zip for a bundle of their own.

## Sources

Manage sources (from the add-on, or its settings) adds an add-on by its install link
(`manifest.json`, `stremio://`, or a Stremio Web link), typed in Kodi or sent from a phone or
computer on the network, and configures, reorders or removes them. Settings: Resolve method
(Automatic / Choose) and the source timeout.

A source can also be a player add-on: another Kodi add-on through a TMDb Helper player file,
picked from TMDb Helper's, Bingie's or skin.ultra's player folders, or browsed for. Its
`play_movie` / `play_episode` path is filled in (`{tmdb}`, `{title_url}`, ...) and handed over
(`is_resolvable: "false"` runs it instead); a `[folder, {rules}]` player's folder is listed and its
matching items offered. They take their place in the sources' order, beside the add-ons' streams.

## For skins

On Home (window 10000): `ultra.player.state` is `choosing` just before the stream list shows,
and `failed` (with `ultra.player.message`) when nothing plays; cleared when a stream is handed over.

## Tests

    python -m unittest discover tests
