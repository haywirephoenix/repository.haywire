"""At login: install Ultra Player's TMDb Helper player file where it's missing (helpers.py),
so TMDb Helper lists Ultra Player without Ultra Player having been opened first; and mark
downloads Kodi closed on as stopped, so Download carries them on.

Then, while Kodi runs: an episode playing through the torrent player (player.NEXT) whose file has
downloaded (Torrest's torrest.download.ready reaches 100) has its next episode downloaded ahead
(setting next_download; next_episode.py), once per episode played."""
import json
import os
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import downloads  # noqa: E402
import helpers  # noqa: E402

DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ultra.player/")
ADDON_ID = "plugin.video.ultra.player"
NEXT = "ultra.player.next"  # player.NEXT
READY = "torrest.download.ready"
POLL = 2


def startup():
    try:
        helpers.install()
    except OSError:
        pass
    try:
        items = downloads.read_index(DATA)
        if any(e.get("status") == "downloading" for e in items.values()):
            for entry in items.values():
                if entry.get("status") == "downloading":
                    entry["status"] = "stopped"
            downloads.write_index(DATA, items)
    except OSError:
        pass


def fetch_next(raw):
    try:
        import next_episode
        next_episode.fetch(json.loads(raw)["values"])
    except Exception as e:  # never take the service down
        xbmc.log("[{}] next episode: {}".format(ADDON_ID, e), xbmc.LOGERROR)


def watch():
    home, monitor, done = xbmcgui.Window(10000), xbmc.Monitor(), None
    while not monitor.waitForAbort(POLL):
        raw = home.getProperty(NEXT)
        if not raw or raw == done or home.getProperty(READY) != "100":
            continue
        if not xbmc.getCondVisibility("Player.HasVideo"):
            continue
        done = raw
        if xbmcaddon.Addon(ADDON_ID).getSetting("next_download") == "true":
            threading.Thread(target=fetch_next, args=(raw,), daemon=True).start()


if __name__ == "__main__":
    startup()
    watch()
