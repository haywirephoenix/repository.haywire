"""Torrent players: the add-on that plays (and downloads) torrent streams, from a torrent player
file, JSON in the style of the player files (players.py):

    "name"             what it's called
    "plugin"           the add-on's id
    "play_magnet"      the path that plays a torrent: {magnet_url} (the magnet, URL-encoded),
                       {magnet}, {info_hash}
    "index"            added to a path when the stream names its file: {index}
    "download_magnet"  (optional) a path that downloads a torrent without playing it (Download)
    "quiet"            (optional) added to a download path that shouldn't notify (the next
                       episode, downloaded ahead on its own)
    "torrents"         (optional) a folder listing the torrents it keeps, each linked by its info
                       hash: a torrent played before plays again from what it kept, with no lookup
    "videos"           (optional) a folder listing a kept torrent's video files ({info_hash}), each
                       labelled with its path in the torrent and linked with file_id=<its index>:
                       a pack's other episodes play (and download ahead) from it, with no lookup
    "priority"         (optional) Auto picks the installed one with the highest

Ultra Player's own are in resources/torrent_players (Torrest); others go in its profile's
torrent_players folder, where one with the same plugin replaces Ultra Player's (Elementum's is
kept aside in extras/, for a bundle of other torrent players). The torrent_player setting is
"auto" or a file's plugin: the one it names while that add-on is installed, else Auto, which
takes Torrest (RECOMMENDED) when it's installed.

No Kodi modules here (tests/test_torrents.py): has_addon is passed in.
"""
import glob
import json
import os
import re

import players

RECOMMENDED = "plugin.video.torrest"
RECOMMENDED_NAME = "Torrest"
AUTO = "auto"


def check(player):
    """Why a torrent player file can't be used, or None."""
    if not isinstance(player, dict):
        return "Not a torrent player file"
    if not isinstance(player.get("plugin"), str) or not player["plugin"]:
        return "The torrent player file names no add-on (\"plugin\")"
    if not isinstance(player.get("play_magnet"), str) or not player["play_magnet"]:
        return "The torrent player file has no play_magnet"
    return None


def load(folders):
    """The usable torrent player files in folders ({plugin: player}); a later folder's file
    replaces an earlier one for the same plugin."""
    found = {}
    for folder in folders:
        for path in sorted(glob.glob(os.path.join(folder, "*.json"))):
            try:
                with open(path, encoding="utf-8") as f:
                    player = json.load(f)
            except (OSError, ValueError):
                continue
            if check(player) is None:
                found[player["plugin"]] = player
    return found


def choose(found, setting, has_addon):
    """The torrent player to use, or None: the setting's while its add-on is installed, else
    the installed one with the highest priority (Torrest first among equals)."""
    if setting and setting != AUTO and setting in found and has_addon(setting):
        return found[setting]
    installed = [p for p in found.values() if has_addon(p["plugin"])]
    if not installed:
        return None
    return max(installed, key=lambda p: (int(p.get("priority") or 0), p["plugin"] == RECOMMENDED))


def name(player):
    return (player or {}).get("name") or (player or {}).get("plugin") or "the torrent add-on"


def path(player, key, info_hash, index=None):
    """The player's key ("play_magnet" / "download_magnet") path for a torrent, with the file
    index when there is one; None when the player has no such path."""
    template = (player or {}).get(key)
    if not template:
        return None
    magnet = "magnet:?xt=urn:btih:{}".format(info_hash)
    values = {"magnet": magnet, "info_hash": info_hash, "index": "" if index is None else str(index)}
    out = players.fill(template, values)
    if index is not None and player.get("index"):
        out += players.fill(player["index"], values)
    return out


def handles(player, play_path):
    """Whether a play path is this player's (one that its torrents folder can tell about)."""
    return bool(player) and str(play_path or "").startswith("plugin://{}/".format(player["plugin"]))


# An episode's numbers in a file name: S01E02 (S01.E02, s1e2), else 1x02.
_SXE = re.compile(r"(?<![a-z0-9])s(\d{1,2})[ ._-]?e(\d{1,3})(?!\d)", re.IGNORECASE)
_NXN = re.compile(r"(?<!\d)(\d{1,2})x(\d{2,3})(?!\d)", re.IGNORECASE)
_FILE_ID = re.compile(r"[?&](?:file_id|index)=(\d+)")


def episode_of(name):
    """(season, episode) a video file's name is, or None."""
    base = (name or "").replace("\\", "/").rsplit("/", 1)[-1]
    found = _SXE.search(base) or _NXN.search(base)
    return (int(found.group(1)), int(found.group(2))) if found else None


def videos_path(player, info_hash):
    """The player's folder listing a torrent's video files, or None."""
    template = (player or {}).get("videos")
    return players.fill(template, {"info_hash": info_hash}) if template else None


def find_episode(items, season, episode):
    """The file index of the episode among a videos listing's items ({"label", "file"}), or
    None. Samples and extras (no episode number) are passed over."""
    for item in items:
        if "sample" in (item.get("label") or "").lower():
            continue
        if episode_of(item.get("label")) == (int(season), int(episode)):
            found = _FILE_ID.search(item.get("file") or "")
            if found:
                return int(found.group(1))
    return None
