"""Downloads: titles saved for later, and their index (downloads.json in Ultra Player's data
folder) that playing checks first (player.local_copy).

    {"items": {key: {"kind", "ids", "season", "episode", "title", "file", "url",
                     "status": "downloading" | "stopped" | "done" | "failed" | "deleted", "size", "done"}}}
"client": a torrent add-on downloads it (url its play path). "streamed": a torrent played through
a torrent add-on (url its play path, with the file index), so a later play of the title can use
the copy the add-on kept, if it still has it, without asking the sources again.

key: the title's kind and first id (an episode's: its show's, then season and episode); it's
found again by any of its ids (one add-on may give only the IMDb id). url: the
stream it's coming from (with any "|headers" Kodi needs), so a title still downloading plays
from there. A download goes to <file>.part and is renamed when complete; one stopped part-way
(Kodi closed) carries on from where it was, if the server takes a Range request.

No Kodi modules here (tests/test_downloads.py).
"""
import json
import os
import re
import urllib.request
from urllib.parse import parse_qsl, urlsplit

INDEX = "downloads.json"
CHUNK = 1 << 20
VIDEO_EXTENSIONS = (".mp4", ".mkv", ".avi", ".m4v", ".mov", ".webm", ".ts", ".wmv")


def key(kind, values):
    ident = next(("{}:{}".format(k, values[k]) for k in ("tmdb", "imdb", "tvdb") if values.get(k)), "")
    if kind == "episode":
        return "episode:{}:{}:{}".format(ident, values.get("season", ""), values.get("episode", ""))
    return "movie:" + ident


def ids(values):
    return {k: str(values[k]) for k in ("tmdb", "imdb", "tvdb") if values.get(k)}


def same(entry, kind, values):
    """Whether an index entry is this title: its kind, numbers and any id in common."""
    if entry.get("kind") != kind or not set((entry.get("ids") or {}).items()) & set(ids(values).items()):
        return False
    return kind != "episode" or (str(entry.get("season")), str(entry.get("episode"))) == (
        str(values.get("season", "")), str(values.get("episode", "")))


def read_index(folder):
    try:
        with open(os.path.join(folder, INDEX), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    items = data.get("items") if isinstance(data, dict) else None
    return items if isinstance(items, dict) else {}


def write_index(folder, items):
    os.makedirs(folder, exist_ok=True)
    tmp = os.path.join(folder, INDEX + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"items": items}, f, indent=2)
    os.replace(tmp, os.path.join(folder, INDEX))


def entry_key(items, kind, values):
    return next((k for k, e in items.items() if isinstance(e, dict) and same(e, kind, values)), None)


def show_torrents(folder, values):
    """The play paths of the torrents the show's episodes were played or downloaded from (status
    streamed or client), most recent entries first: where its other episodes may be (a pack)."""
    show = ids(values)
    paths = []
    for entry in reversed(list(read_index(folder).values())):
        if not isinstance(entry, dict) or entry.get("kind") != "episode":
            continue
        shared = set((entry.get("ids") or {}).items()) & set(show.items())
        if shared and entry.get("status") in ("streamed", "client") and entry.get("url") and entry["url"] not in paths:
            paths.append(entry["url"])
    return paths


def find(folder, kind, values):
    """The title's index entry, by any of its ids, or None."""
    items = read_index(folder)
    k = entry_key(items, kind, values)
    return items[k] if k else None


def update(folder, kind, values, **fields):
    """Sets fields on the title's entry (made under key()), adding any ids it hadn't, and
    returns it."""
    items = read_index(folder)
    k = entry_key(items, kind, values) or key(kind, values)
    entry = items.setdefault(k, {"kind": kind, "ids": {}})
    entry["ids"] = dict(entry.get("ids") or {}, **ids(values))
    if kind == "episode":
        entry.update(season=values.get("season", ""), episode=values.get("episode", ""))
    entry.update(fields)
    write_index(folder, items)
    return entry


def safe(text):
    return re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", text)).strip(" .") or "Video"


def file_name(kind, values, url):
    """"Show S01E02 - Title.mkv" / "Title (Year).mp4", the extension from the link."""
    path = urlsplit(url.split("|")[0]).path.lower()
    ext = next((e for e in VIDEO_EXTENSIONS if path.endswith(e)), ".mp4")
    if kind == "episode":
        season, episode = values.get("season", ""), values.get("episode", "")
        number = "S{:02d}E{:02d}".format(int(season), int(episode)) if season.isdigit() and episode.isdigit() else ""
        name = " ".join(p for p in (values.get("showname", ""), number) if p)
        if values.get("title"):
            name += " - " + values["title"]
    else:
        name = values.get("title", "") + (" ({})".format(values["year"]) if values.get("year") else "")
    return safe(name) + ext


def split_url(url):
    """(url, headers) from Kodi's "url|Header=value&..." form."""
    link, _, headers = url.partition("|")
    return link, dict(parse_qsl(headers))


def fetch(url, target, progress=None, stopped=None, timeout=30):
    """Downloads url to target (via target.part, resuming it). progress(done, total) after each
    chunk; stopped() true halts it (the part is kept). Returns "done" or "stopped"; raises
    OSError on a failure."""
    link, headers = split_url(url)
    headers.setdefault("User-Agent", "Mozilla/5.0")
    part = target + ".part"
    have = os.path.getsize(part) if os.path.exists(part) else 0
    if have:
        headers["Range"] = "bytes={}-".format(have)
    request = urllib.request.Request(link, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if have and response.status != 206:  # no resume: start again
            have = 0
        length = int(response.headers.get("Content-Length") or 0)
        total = have + length if length else 0
        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
        with open(part, "ab" if have else "wb") as f:
            done = have
            while True:
                if stopped and stopped():
                    return "stopped"
                chunk = response.read(CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
    if total and done < total:
        raise OSError("the download ended early ({} of {} bytes)".format(done, total))
    os.replace(part, target)
    return "done"
