"""Ultra Player's routes.

    plugin://plugin.video.ultra.player/                  the add-on's menu
    plugin://plugin.video.ultra.player/play?kind=...     play a title (resources/lib/player.py)
    plugin://plugin.video.ultra.player/sources           Manage sources (resources/lib/manage.py)
    plugin://plugin.video.ultra.player/install_players   (re)install its TMDb Helper player file

Every run first installs the TMDb Helper player file where it's missing (helpers.py).
"""
import os
import sys
from urllib.parse import parse_qsl, urlsplit

import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import helpers  # noqa: E402
import manage  # noqa: E402
import player  # noqa: E402

BASE = "plugin://{}/".format(player.ADDON_ID)


def menu(handle):
    for label, path, folder in (("Manage sources", BASE + "sources", False),
                                ("Install TMDb Helper player", BASE + "install_players", False),
                                ("Settings", BASE + "settings", False)):
        xbmcplugin.addDirectoryItem(handle, path, xbmcgui.ListItem(label, offscreen=True), isFolder=folder)
    xbmcplugin.endOfDirectory(handle)


def install_players():
    """Puts the player file into each TMDb helper's players folder, over an older copy."""
    try:
        written, found = helpers.install(force=True)
    except OSError as e:
        xbmcgui.Dialog().ok("Ultra Player", "Couldn't install the player file: {}".format(e))
        return
    if not found:
        xbmcgui.Dialog().ok("Ultra Player", "TMDb Helper isn't installed.")
        return
    xbmcgui.Dialog().ok("Ultra Player", "Installed for {}. Pick Ultra Player in its player list (or as its "
                        "default player in its settings).".format(" and ".join(written)))


def main(argv):
    route = urlsplit(argv[0]).path.strip("/")
    handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    params = dict(parse_qsl(argv[2].lstrip("?"))) if len(argv) > 2 else {}
    route = params.pop("action", route)
    try:
        helpers.install()
    except OSError as e:
        player.log("couldn't install the TMDb Helper player file: {}".format(e))
    if route == "play":
        player.play(handle, params)
    elif route == "sources":
        manage.run()
    elif route == "install_players":
        install_players()
    elif route == "settings":
        xbmcaddon.Addon(player.ADDON_ID).openSettings()
    else:
        menu(handle)


if __name__ == "__main__":
    main(sys.argv)
