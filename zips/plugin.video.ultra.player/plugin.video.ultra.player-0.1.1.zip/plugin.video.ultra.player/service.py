"""At login: install Ultra Player's TMDb Helper player file where it's missing (helpers.py),
so TMDb Helper lists Ultra Player without Ultra Player having been opened first. Then exits."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import helpers  # noqa: E402

if __name__ == "__main__":
    try:
        helpers.install()
    except OSError:
        pass
