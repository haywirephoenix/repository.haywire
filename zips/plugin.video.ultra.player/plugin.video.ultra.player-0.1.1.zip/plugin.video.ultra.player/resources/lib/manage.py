"""Manage sources (plugin://plugin.video.ultra.player/sources): the sources list, with Add,
and for each source Configure (when its manifest says it can be), Change link, Reload its
manifest, Move up / down and Remove. Saved in store.py's sources.json as each change is made.

Adding or configuring takes an add-on link (manifest.json, stremio:// or a Stremio Web link):
typed or pasted here, or sent from a phone or computer on the network (configure.receive),
with the add-on's configure page opened on this device first where it has a browser.
"""
import os
import sys
from urllib.parse import urlsplit

import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import configure  # noqa: E402
import player  # noqa: E402
import store  # noqa: E402
import streams  # noqa: E402

HEADING = "Manage sources"


def notify(message, error=False):
    xbmcgui.Dialog().notification("Ultra Player", message,
                                  xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 5000)


def fetch_source(link, folder):
    """{"name", "manifest"} for an add-on link (its manifest fetched and cached), or None
    after saying what's wrong."""
    url = streams.manifest_link(link)
    if not url.startswith(("https://", "http://")) or not url.split("?", 1)[0].endswith("manifest.json"):
        notify("Not an add-on link: it ends in manifest.json", error=True)
        return None
    try:
        manifest = streams.fetch_json(url)
    except (OSError, ValueError) as e:
        notify("Couldn't load the add-on: {}".format(e), error=True)
        return None
    problem = streams.check_manifest(manifest)
    if problem:
        notify(problem, error=True)
        return None
    cache = streams.read_cache(store.manifest_cache(folder))
    cache[url] = manifest
    os.makedirs(folder, exist_ok=True)
    streams.write_cache(store.manifest_cache(folder), cache)
    return {"name": str(manifest.get("name") or manifest["id"]), "manifest": url}


def ask_link(heading, name, configure_url=None, current=""):
    """A new add-on link: typed or pasted here, or sent from another device's browser (with the
    configure page, when there is one, opened here first if this device has a browser)."""
    dialog = xbmcgui.Dialog()
    options = []
    if configure_url and configure.can_open_here():
        options.append(("Open the configure page here, then paste the link", "here"))
    options.append(("Use a phone or computer on this network", "device"))
    options.append(("Type or paste the link here", "type"))
    choice = dialog.select(heading, [o[0] for o in options])
    if choice < 0:
        return None
    how = options[choice][1]
    if how == "device":
        return configure.receive(heading, name, configure_url)
    if how == "here" and not configure.open_here(configure_url):
        notify("Couldn't open a browser here", error=True)
        return None
    return dialog.input("{}: install link (manifest.json or stremio://)".format(name), current) or None


def run():
    dialog = xbmcgui.Dialog()
    folder = player.data_dir()
    while True:
        sources = store.read_sources(folder)
        cache = streams.read_cache(store.manifest_cache(folder))
        items = []
        for n, source in enumerate(sources):
            manifest = cache.get(source["manifest"]) or {}
            hints = manifest.get("behaviorHints") or {}
            item = xbmcgui.ListItem("{}. {}".format(n + 1, source.get("name") or manifest.get("name") or "?"), offscreen=True)
            item.setLabel2(urlsplit(source["manifest"]).netloc + ("  (configurable)" if hints.get("configurable") else ""))
            items.append(item)
        items.append(xbmcgui.ListItem("[B]Add a source...[/B]", "A Stremio or Nuvio add-on's install link", offscreen=True))
        choice = dialog.select(HEADING, items, useDetails=True)
        if choice < 0:
            return
        if choice == len(sources):
            link = ask_link("Add a source", "New source")
            source = fetch_source(link, folder) if link else None
            if source:
                store.write_sources(folder, sources + [source])
            continue

        n, source = choice, sources[choice]
        name = source.get("name") or "Source"
        configurable = ((cache.get(source["manifest"]) or {}).get("behaviorHints") or {}).get("configurable")
        actions = (["Configure..."] if configurable else []) + ["Change link...", "Reload its manifest"]
        actions += (["Move up"] if n > 0 else []) + (["Move down"] if n < len(sources) - 1 else []) + ["Remove"]
        pick = dialog.select(name, actions)
        if pick < 0:
            continue
        action = actions[pick]
        if action in ("Configure...", "Change link..."):
            link = ask_link(name, name, streams.configure_url(source["manifest"]) if action == "Configure..." else None,
                            source["manifest"])
            replaced = fetch_source(link, folder) if link else None
            if replaced:
                sources[n] = replaced
        elif action == "Reload its manifest":
            replaced = fetch_source(source["manifest"], folder)
            if replaced:
                sources[n] = replaced
        elif action == "Move up":
            sources.insert(n - 1, sources.pop(n))
        elif action == "Move down":
            sources.insert(n + 1, sources.pop(n))
        elif dialog.yesno(HEADING, "Remove {}?".format(name)):
            sources.pop(n)
        else:
            continue
        store.write_sources(folder, sources)
