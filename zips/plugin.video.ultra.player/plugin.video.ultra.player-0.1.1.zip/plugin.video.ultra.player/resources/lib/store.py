"""Ultra Player's own data, in its addon_data folder:

    sources.json    {"sources": [{"name": ..., "manifest": "https://.../manifest.json"}, ...]}
    manifests.json  {manifest URL: manifest}, filled when a source is added or reloaded

Paths are passed in, so this needs no Kodi modules (tests/test_streams.py).
"""
import json
import os


def read_sources(folder):
    try:
        with open(os.path.join(folder, "sources.json"), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    sources = data.get("sources") if isinstance(data, dict) else None
    return [s for s in sources or [] if isinstance(s, dict) and isinstance(s.get("manifest"), str)]


def write_sources(folder, sources):
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, "sources.json"), "w", encoding="utf-8") as f:
        json.dump({"sources": sources}, f, indent=2)


def manifest_cache(folder):
    return os.path.join(folder, "manifests.json")
