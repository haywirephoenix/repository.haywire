"""Playing a title from the sources (plugin://plugin.video.ultra.player/play?...).

The play URL carries what's known about the title, the same names a TMDb Helper player file
fills in (resources/players/ultra.player.json):

    kind      movie or episode
    tmdb, imdb, tvdb   ids (an episode's are its show's)
    season, episode    an episode's numbers
    title     the movie's title, or the episode's
    showname  an episode's show
    year, poster, fanart

Every source is asked for streams at once; then the first playable one plays (setting resolve
"auto") or the one picked from the list ("choose"). As a resolvable plugin it hands Kodi the
stream through setResolvedUrl; run by RunPlugin (no handle) it plays it itself.

For skins it reports on Home (window 10000), so a loading screen can follow:
    ultra.player.state    "choosing" just before the list shows (the screen should step aside),
                          "failed" when nothing plays (with ultra.player.message saying why);
                          cleared when it hands a stream over.
"""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import store  # noqa: E402
import streams  # noqa: E402

ADDON_ID = "plugin.video.ultra.player"
STATE, MESSAGE = "ultra.player.state", "ultra.player.message"


def log(msg):
    xbmc.log("[{}] {}".format(ADDON_ID, msg), xbmc.LOGINFO)


def data_dir():
    return xbmcvfs.translatePath("special://profile/addon_data/{}/".format(ADDON_ID))


def settings():
    addon = xbmcaddon.Addon(ADDON_ID)
    resolve = addon.getSetting("resolve") or "auto"
    try:
        timeout = max(3, min(60, int(addon.getSetting("timeout") or streams.TIMEOUT)))
    except ValueError:
        timeout = streams.TIMEOUT
    return resolve, timeout


def values_from(params):
    """The play URL's values, with the names streams.item_ids and the list item use."""
    values = {k: str(params.get(k) or "") for k in ("tmdb", "imdb", "tvdb", "season", "episode", "title",
                                                    "showname", "year", "poster", "fanart")}
    kind = "episode" if params.get("kind") == "episode" else "movie"
    return kind, values


def fail(handle, message):
    home = xbmcgui.Window(10000)
    home.setProperty(MESSAGE, message)
    home.setProperty(STATE, "failed")
    xbmcgui.Dialog().notification("Ultra Player", message, xbmcgui.NOTIFICATION_WARNING, 5000)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def no_streams_reason(kind, report, dropped):
    """The notice when nothing can play: the first source's reason, in a few words."""
    for entry in report:
        if dropped.get(entry["name"]):
            why, n = max(dropped[entry["name"]].items(), key=lambda kv: kv[1])
            return "{}: {} {}".format(entry["name"], n, streams.DROPPED[why])
    for entry in report:
        if entry.get("error"):
            return "{}: {}".format(entry["name"], entry["error"])
    for entry in report:
        if "skipped" in entry:
            return "{}: {}".format(entry["name"], entry["skipped"])
    empty = [entry["name"] for entry in report if "seconds" in entry]
    if empty:  # asked and answered, with nothing: its own settings (providers, quality filter) rule them out
        return "{} found no streams for this {}: check {} Configure settings".format(
            " and ".join(empty), kind, "their" if len(empty) > 1 else "its")
    return "No streams found for this {}".format(kind)


def list_item(kind, values, path):
    title = values.get("title") or values.get("showname") or ""
    item = xbmcgui.ListItem(title, path=path, offscreen=True)
    tag = item.getVideoInfoTag()
    tag.setMediaType(kind)
    tag.setTitle(title)
    if kind == "episode":
        tag.setTvShowTitle(values.get("showname") or "")
        if values.get("season", "").isdigit() and values.get("episode", "").isdigit():
            tag.setSeason(int(values["season"]))
            tag.setEpisode(int(values["episode"]))
    else:
        ids = {k: values[k] for k in ("tmdb", "imdb", "tvdb") if values.get(k)}
        if ids:
            tag.setUniqueIDs(ids, "imdb" if "imdb" in ids else next(iter(ids)))
    item.setArt({k: values[k] for k in ("poster", "fanart") if values.get(k)})
    return item


def play(handle, params):
    home = xbmcgui.Window(10000)
    home.clearProperty(STATE)
    home.clearProperty(MESSAGE)
    kind, values = values_from(params)
    if not (values["tmdb"] or values["imdb"]):
        fail(handle, "No TMDb or IMDb id for this {}".format(kind))
        return
    folder = data_dir()
    sources = store.read_sources(folder)
    if not sources:
        fail(handle, "No sources yet: add some in Ultra Player > Manage sources")
        return
    resolve, timeout = settings()
    found = streams.manifests(sources, store.manifest_cache(folder))
    installed = {a for a in ("plugin.video.youtube",) + tuple(t[0] for t in streams.TORRENT_PLAYERS)
                 if xbmc.getCondVisibility("System.HasAddon({})".format(a))}
    got, report = streams.gather(sources, found, kind, values, timeout)
    offered, dropped = [], {}
    for source_name, stream in got:
        target, why = streams.classify(stream, installed)
        if target:
            offered.append((source_name, stream, target))
        else:
            dropped.setdefault(source_name, {}).setdefault(why, 0)
            dropped[source_name][why] += 1
    log("{} {}: {} sources, resolve {}, timeout {}s, players installed: {}".format(
        kind, streams.item_ids(kind, values), len(sources), resolve, timeout, ", ".join(sorted(installed)) or "none"))
    for entry in report:
        state = ("skipped: " + entry["skipped"]) if "skipped" in entry else (
            "{} streams in {}s".format(entry["streams"], entry["seconds"]) + (", " + entry["error"] if entry.get("error") else ""))
        why = ", ".join("{} {}".format(n, streams.DROPPED[k]) for k, n in sorted(dropped.get(entry["name"], {}).items()))
        log("  {}: {} - {}{}".format(entry["name"], entry["url"], state, "; left out: " + why if why else ""))
    log("{} playable".format(len(offered)))
    if not offered:
        fail(handle, no_streams_reason(kind, report, dropped))
        return

    if resolve == "choose":
        home.setProperty(STATE, "choosing")
        items = []
        for source_name, stream, _ in offered:
            label, details = streams.describe(stream)
            items.append(xbmcgui.ListItem("[{}]  {}".format(source_name, label), details, offscreen=True))
        choice = xbmcgui.Dialog().select("Sources: {}".format(values.get("title") or values.get("showname")), items,
                                         useDetails=True)
        home.clearProperty(STATE)
        if choice < 0:
            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
            return
        _, stream, (path, how) = offered[choice]
    else:
        _, stream, (path, how) = offered[0]
    label, details = streams.describe(stream)
    log("{} through {} ({}): {} {}".format(kind, streams.redact(path.split("|")[0]) if how == "url" else path.split("?")[0],
                                           how, label, details))
    item = list_item(kind, values, path)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, item)
    else:
        xbmc.Player().play(path, item)
