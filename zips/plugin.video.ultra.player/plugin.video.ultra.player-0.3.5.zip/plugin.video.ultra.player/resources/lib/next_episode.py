"""Downloading the next episode ahead (settings next_download, next_resolve).

Once the episode playing through the torrent player (player.NEXT) has downloaded, the service
calls fetch(): the next episode (this season's next, else the next season's first) starts
downloading through the torrent player, unless it already has a copy (downloaded, under way, a
torrent kept for it):
  1. from a torrent of the show the torrent player keeps that has it (a pack): just that file;
  2. else, with next_resolve, from the sources: the first torrent offered (in the sources'
     order, as Resolve auto would pick), handed to the torrent player as a download.
Either is recorded as a download with the client (downloads.py "client"), so playing it later
needs no lookup.
"""
import xbmc
import xbmcaddon

import downloads
import player
import streams
import torrents


def enabled(setting):
    return xbmcaddon.Addon(player.ADDON_ID).getSetting(setting) == "true"


def candidates(values):
    """The next episode's values: this season's next, then the next season's first."""
    try:
        season, episode = int(values.get("season")), int(values.get("episode"))
    except (TypeError, ValueError):
        return []
    return [dict(values, season=str(s), episode=str(e), title="") for s, e in ((season, episode + 1), (season + 1, 1))]


def has_copy(values):
    entry = downloads.find(player.data_dir(), "episode", values)
    if not entry:
        return False
    if entry.get("status") in ("done", "downloading"):
        return True
    return entry.get("status") in ("client", "streamed") and player.torrent_kept(entry.get("url") or "")


def download(torrent, values, info_hash, index, how):
    url = torrents.path(torrent, "download_magnet", info_hash, index)
    play_path = torrents.path(torrent, "play_magnet", info_hash, index)
    if not url:
        return False
    url += torrent.get("quiet") or ""  # no "added" popup for a download nobody asked for just now
    name = "{} S{:0>2}E{:0>2}".format(values.get("showname") or "", values["season"], values["episode"])
    downloads.update(player.data_dir(), "episode", values, title=name, file="", url=play_path, status="client",
                     meta=downloads.meta(values))
    player.log("next episode {}: downloading it ahead {}".format(streams.item_ids("episode", values), how))
    xbmc.executebuiltin('RunPlugin("{}")'.format(url))
    return True


def fetch(values):
    torrent = player.torrent_player()
    if not torrent or not torrent.get("download_magnet"):
        return
    nexts = candidates(values)
    for nxt in nexts:
        if has_copy(nxt):
            player.log("next episode {}: already there".format(streams.item_ids("episode", nxt)))
            return
    paths = downloads.show_torrents(player.data_dir(), values)
    for nxt in nexts:
        found = player.pack_file(nxt, paths)
        if found:
            download(torrent, nxt, found[0], found[1], "from the pack it's in")
            return
    if not enabled("next_resolve"):
        player.log("next episode of {}: not in a kept torrent".format(streams.item_ids("episode", values)))
        return
    for nxt in nexts:
        offered, why = player.find_offers("episode", nxt)
        for _, stream, (_, how) in offered:
            if how == "torrent" and stream.get("infoHash"):
                download(torrent, nxt, stream["infoHash"].lower(), stream.get("fileIdx"), "from the sources")
                return
        player.log("next episode {}: no torrent offered ({})".format(streams.item_ids("episode", nxt), why or "none"))
