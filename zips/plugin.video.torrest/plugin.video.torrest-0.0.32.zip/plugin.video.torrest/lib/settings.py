from xbmc import getCondVisibility

from lib.kodi import get_int_setting, get_boolean_setting, get_setting, set_boolean_setting

ULTRA_PLAYER_ID = "plugin.video.ultra.player"


class FilesOrder:
    ID = 0
    NAME = 1
    SIZE = 2


class TrackersMode:
    ALL = 0
    NO_TRACKERS = 1
    DISABLED = 2


class PlaybackStopAction:
    ASK_TO_DELETE = 0
    DELETE = 1
    IGNORE = 2


class PlayFilesWith:
    TORREST = 0
    ULTRA_PLAYER = 1


class DeleteAction:
    AUTO = 0
    ASK = 1


def get_port():
    return get_int_setting("port")


def show_daemon_notification():
    return get_boolean_setting("daemon_notification")


def get_daemon_timeout():
    return get_int_setting("timeout")


def get_metadata_timeout():
    # 0 is no limit
    return get_int_setting("metadata_timeout") if get_boolean_setting("limit_metadata_timeout") else 0


def get_trackers_mode():
    return get_int_setting("trackers")


def get_tracker_max_failures():
    return get_int_setting("tracker_max_failures")


def get_buffer_start_size():
    return get_int_setting("buffer_start") * 1024 * 1024


def get_buffer_end_size():
    return get_int_setting("buffer_end") * 1024 * 1024


def get_buffering_timeout():
    # 0 is no limit
    return get_int_setting("buffer_timeout") if get_boolean_setting("limit_buffer_timeout") else 0


def keep_packs():
    return get_boolean_setting("keep_packs")


def delete_watched_from_packs():
    return get_boolean_setting("delete_watched_from_packs")


def pause_when_behind():
    return get_boolean_setting("pause_when_behind")


def get_resume_ahead():
    return get_int_setting("resume_ahead")


def limit_piece_wait():
    return get_boolean_setting("limit_piece_wait_timeout")


def show_status_overlay():
    return get_boolean_setting("overlay")


def get_min_candidate_size():
    return get_int_setting("min_candidate_size")


def get_on_playback_stop_action():
    return get_int_setting("on_playback_stop")


def delete_unstarted():
    return get_boolean_setting("delete_unstarted")


def get_delete_action():
    return get_int_setting("delete_action")


def get_unstarted_percent():
    return get_int_setting("unstarted_percent")


def stop_on_exit():
    return get_boolean_setting("stop_on_exit")


def stop_when_complete():
    return get_boolean_setting("stop_when_complete")


def stop_at_startup():
    return get_boolean_setting("stop_at_startup")


def delete_watched():
    return get_boolean_setting("delete_watched")


def get_watched_percent():
    return get_int_setting("watched_percent")


def service_enabled():
    return get_boolean_setting("service_enabled")


def ssl_enabled():
    return get_boolean_setting("ssl_connection")


def set_service_enabled(value):
    set_boolean_setting("service_enabled", value)


def get_service_address():
    return "127.0.0.1" if service_enabled() else get_setting("service_address")


def download_after_insert():
    return get_boolean_setting("download_after_insert")


def folder_listing_enabled():
    return get_boolean_setting("enable_folders")


def skip_root_folder():
    return get_boolean_setting("skip_root_folder")


def get_files_order():
    return get_int_setting("files_order")


def show_background_progress():
    return get_boolean_setting("show_bg_progress")


def set_has_libtorrest(value):
    set_boolean_setting("has_libtorrest", value)


def get_force_torrest():
    return get_boolean_setting("force_torrest")


def play_with_ultra_player():
    """Whether a file played from the manager or a file listing goes to Ultra Player (when it's
    installed: else Torrest plays it)."""
    return (get_int_setting("play_files_with") == PlayFilesWith.ULTRA_PLAYER
            and getCondVisibility("System.HasAddon({})".format(ULTRA_PLAYER_ID)))
