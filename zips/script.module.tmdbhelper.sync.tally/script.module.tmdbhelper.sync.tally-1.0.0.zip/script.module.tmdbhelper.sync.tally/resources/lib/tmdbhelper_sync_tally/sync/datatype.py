from jurialmunkey.ftools import cached_property
from jurialmunkey.parser import try_int
from tmdbhelper.lib.sync.datatype import DataType, DataTypeEpisodesInShows, DataTypeShowsToEpisodes


class TallyDataType(DataType):
    """ Reads Tally's local database through tmdbhelper_sync_tally.records """

    @property
    def tally_store(self):
        return self.provider.api

    @cached_property
    def is_expired(self):
        return super().is_expired or self.is_changed_elsewhere

    @cached_property
    def is_changed_elsewhere(self):
        return self.get_is_changed_elsewhere()

    def get_is_changed_elsewhere(self):
        """ Tally data changed by plugin.video.tally (or this provider) since this type last synced """
        from datetime import datetime, timezone
        from tmdbhelper.lib.addon.tmdate import get_timestring_zulu
        from tmdbhelper_sync_tally.tally import get_tally_reload
        reload_time = try_int(get_tally_reload())
        if not reload_time or not self.timestamp:
            return False
        return get_timestring_zulu(datetime.fromtimestamp(reload_time / 1000, timezone.utc)) > self.timestamp

    def get_syncitem(self, meta):
        from tmdbhelper_sync_tally.sync.itemdata import TallySyncItem
        return TallySyncItem(self.item_type, meta, self.keys, key_prefix=self.key_prefix)

    def get_records(self, store):
        raise NotImplementedError

    def get_response_sync(self, *args, **kwargs):
        """ None (a failed sync, keeping what was synced before) when the database can't be read """
        if not self.tally_store:
            return
        try:
            return self.get_records(self.tally_store)
        except Exception as exc:  # Database busy or broken
            from tmdbhelper.lib.addon.logger import kodi_log
            kodi_log(f'Tally sync {self.method} {self.item_type} failed: {exc}', 1)
            return


class TallyDataTypeEpisodesInShows(DataTypeEpisodesInShows, TallyDataType):
    pass


class TallyDataTypeShowsToEpisodes(DataTypeShowsToEpisodes, TallyDataType):
    pass
