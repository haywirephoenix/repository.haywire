from jurialmunkey.ftools import cached_property


class TallyLastActivities:
    """
    Tally has no last activities so derive them from a fingerprint of each list in its database
    Keys match the MDbList sync/last_activities response used by SOURCE_ACTIVITIES
    """

    property_prefix = 'Tally.Activity'

    def __init__(self, store):
        self.store = store

    @cached_property
    def fingerprints(self):
        try:
            return self.store.activity()
        except Exception:  # Database busy or broken: no activity rather than a failed sync
            return {}

    def get_value(self, name):
        from jurialmunkey.window import get_property
        from tmdbhelper.lib.addon.tmdate import get_timestring_zulu_now
        from tmdbhelper_sync_tally.records import activity_value, zulu
        fingerprint = self.fingerprints.get(name)
        if not fingerprint:
            return
        property_name = f'{self.property_prefix}.{name}'
        previous = get_property(property_name)
        get_property(property_name, set_property=fingerprint)
        try:
            newest = zulu(float(fingerprint.split('|')[1]))
        except ValueError:  # Empty list
            newest = None
        return activity_value(fingerprint, previous, newest, get_timestring_zulu_now())

    @cached_property
    def movie_watched_at(self):
        return self.get_value('movie_plays')

    @cached_property
    def episode_watched_at(self):
        return self.get_value('episode_plays')

    @cached_property
    def watchlisted_at(self):
        return self.get_value('watchlist')

    @cached_property
    def paused_at(self):
        return self.get_value('progress')

    @cached_property
    def any_activity_at(self):
        """ Watching an item takes it off the watchlist so also resync that on any new activity """
        return max((i for i in (
            self.movie_watched_at,
            self.episode_watched_at,
            self.watchlisted_at,
            self.paused_at,
        ) if i), default=None)

    @cached_property
    def data(self):
        if not self.any_activity_at:
            return {}
        return {
            'watched_at': self.movie_watched_at,
            'episode_watched_at': self.episode_watched_at,
            'paused_at': self.paused_at,
            'episode_paused_at': self.paused_at,
            'watchlisted_at': self.any_activity_at,
            'collected_at': None,
        }
