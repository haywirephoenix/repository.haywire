from tmdbhelper.lib.addon.consts import HALFDAY_EXPIRY
from tmdbhelper.lib.sync.datatype import timerlock
from tmdbhelper_sync_tally import records
from tmdbhelper_sync_tally.sync.datatype import (
    TallyDataType,
    TallyDataTypeEpisodesInShows,
    TallyDataTypeShowsToEpisodes,
)


class SyncWatched(TallyDataTypeEpisodesInShows):
    keys = ('plays', 'last_watched_at', 'last_updated_at', 'aired_episodes', 'watched_episodes', 'reset_at', )
    last_activities_key = 'watched_at'
    method = 'watched'

    def get_records(self, store):
        if self.item_type == 'movie':
            return records.watched_movies(store)
        return records.watched_shows(store)


class SyncPlayback(TallyDataTypeShowsToEpisodes):
    keys = ('progress', 'paused_at', 'id', )
    last_activities_key = 'paused_at'
    method = 'playback'
    key_prefix = 'playback'

    def get_records(self, store):
        return records.playback(store, self.item_type)


class SyncWatchlist(TallyDataType):
    keys = ('rank', 'listed_at', 'notes', )
    last_activities_key = 'watchlisted_at'
    method = 'watchlist'
    key_prefix = 'watchlist'

    def get_records(self, store):
        return records.watchlist(store, self.item_type)


class SyncNextEpisodes(TallyDataTypeEpisodesInShows):
    keys = ('next_episode_id', 'next_episode_aired_at', )
    last_activities_key = 'watched_at'
    method = 'nextup'
    expiry_time = HALFDAY_EXPIRY

    def get_records(self, store):
        if self.item_type == 'movie':
            return []
        return records.next_episodes(store)


class SyncAllNextEpisodes(TallyDataTypeEpisodesInShows):
    keys = ('upnext_episode_id', )
    last_activities_key = 'watched_at'
    method = 'all_next_episodes'
    expiry_time = HALFDAY_EXPIRY

    @timerlock
    def sync_func(self):
        """ Get next episodes from watched Tally episodes """
        from tmdbhelper.lib.addon.logger import TimerFunc
        from tmdbhelper_sync_tally.sync.nextmeta import TallySyncAllNextEpisodesMeta
        with TimerFunc(
            f'Sync: {self.__class__.__name__} get_meta {self.method} {self.item_type}',
            inline=True,
            log_threshold=0.001
        ):
            return TallySyncAllNextEpisodesMeta(self).items
