"""
Turn Tally's tracking database into the flat sync records read by TallySyncItemData
Plain Python (no Kodi or TMDbHelper imports) so it runs, and is tested, outside Kodi

Every function takes Tally's Store (plugin.video.tally resources/lib/store.py)

EXAMPLE OUTPUT (watched_shows)
{
    "type": "show",
    "tmdb_id": 1396,
    "title": "Breaking Bad",
    "year": 2008,
    "episodes_left": 59,
    "plays": 3,
    "last_watched_at": "2026-10-19T23:53:08.000000Z",
    "seasons": [
        {
            "number": 1,
            "episodes": [
                {"number": 1, "plays": 1, "last_watched_at": "2026-10-19T23:53:08.000000Z"},
            ]
        }
    ]
}
"""
from datetime import datetime, timezone


# Tally's statuses (plugin.video.tally resources/lib/model.py), the same values as Floppy's
STATUS_PLANNING = 0

# Read every row: a household tracks hundreds of titles, not millions
ALL = 1000000


def zulu(timestamp):
    """ Tally's epoch seconds as TMDbHelper's timestamps """
    if not timestamp:
        return
    return datetime.fromtimestamp(timestamp, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')


def try_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return


def title_kind(item_type):
    """ Tally's title kind for a TMDbHelper item type: movie or tv """
    return 'movie' if item_type == 'movie' else 'tv'


def get_meta(row):
    row = row or {}
    return {
        'tmdb_id': try_int(row.get('tmdb')),
        'title': row.get('title') or None,
        'year': row.get('year') or None,
        'premiered': None,
        'status': None,
        'country': None,
        'runtime': None,
    }


def get_record_base(row, record_type, season_number=None, episode_number=None):
    return {
        **get_meta(row),
        'type': record_type,
        'season_number': season_number,
        'episode_number': episode_number,
    }


def get_states(store, kind, tmdb_ids):
    """ Tracked titles by tmdb id: {tmdb: row} """
    return store.states(kind, list(tmdb_ids))


def watched_movies(store):
    plays = store.play_counts('movie')
    states = get_states(store, 'movie', (i['tmdb'] for i in plays))
    return [
        {
            **get_record_base(states.get(i['tmdb']) or {'tmdb': i['tmdb']}, 'movie'),
            'plays': i['plays'],
            'last_watched_at': zulu(i['last_watched_at']),
        }
        for i in plays
    ]


def watched_shows(store):
    """ Watched episodes nested under their show in the Trakt sync/watched layout read by SyncItemConstructor """
    shows = {}
    for i in store.play_counts('episode'):
        seasons = shows.setdefault(i['tmdb'], {})
        seasons.setdefault(i['season'], []).append({
            'number': i['episode'],
            'plays': i['plays'],
            'last_watched_at': zulu(i['last_watched_at']),
        })
    states = get_states(store, 'tv', shows)
    data = []
    for tmdb, seasons in shows.items():
        row = states.get(tmdb) or {'tmdb': tmdb}
        episodes = [j for i in seasons.values() for j in i]
        data.append({
            **get_meta(row),
            'type': 'show',
            'episodes_left': row.get('episodes_left'),
            'plays': sum(i['plays'] for i in episodes),
            'last_watched_at': max(i['last_watched_at'] for i in episodes),
            'seasons': [{'number': k, 'episodes': v} for k, v in seasons.items()],
        })
    return data


def playback(store, item_type):
    """ Resume points of movies, or of episodes for any TV item type """
    kind = 'movie' if item_type == 'movie' else 'episode'
    data = []
    for i in store.resume_list((kind, ), limit=ALL):
        if not i['duration']:
            continue
        movie = kind == 'movie'
        data.append({
            'type': kind,
            'tmdb_id': try_int(i['tmdb']),
            'season_number': None if movie else i['season'],
            'episode_number': None if movie else i['episode'],
            'title': i.get('media_title') or i.get('title') or None,
            'progress': min(i['position'] / i['duration'] * 100, 100),
            'paused_at': zulu(i['updated_at']),
            'id': int(i['position']),  # Tally has no playback id so the resume position marks an active entry
        })
    return data


def watchlist(store, item_type):
    """ Titles on the watchlist (status Planning): movies, or shows; Tally has no season or episode watchlist """
    if item_type not in ('movie', 'show'):
        return []
    return [
        {
            **get_record_base(i, item_type),
            'listed_at': zulu(i['added_at']),
            'notes': None,
        }
        for i in store.titles(title_kind(item_type), [STATUS_PLANNING], order='added', limit=ALL)
    ]


def next_episodes(store):
    """ Each show in progress with its next aired episode """
    return [
        {
            **get_record_base(i, 'show'),
            'next_episode_id': f'tv.{i["tmdb"]}.{i["next_season"]}.{i["next_episode"]}',
            'next_episode_aired_at': (
                f'{i["next_aired"][:10]}T00:00:00.000Z' if i.get('next_aired') else zulu(i['activity_at'])),
        }
        for i in store.next_up(limit=ALL)
    ]


def activity_value(fingerprint, previous, newest, now):
    """
    Last activity of one Tally list from its fingerprint ("count|newest")
    A fingerprint that changed since the last check is reported as now so a removal still resyncs
    """
    if previous and previous != fingerprint:
        return now
    return newest
