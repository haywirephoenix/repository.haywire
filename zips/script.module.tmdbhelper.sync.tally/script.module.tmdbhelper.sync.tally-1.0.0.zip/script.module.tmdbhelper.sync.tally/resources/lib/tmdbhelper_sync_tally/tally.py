from jurialmunkey.plugin import KodiPlugin


ADDON_ID = 'script.module.tmdbhelper.sync.tally'
TALLY_PLUGIN_ID = 'plugin.video.tally'
TALLY_DB_NAME = 'tally.db'
TALLY_RELOAD_PROPERTY = 'tally.widget_reload'  # Home window property shared with plugin.video.tally (milliseconds)

get_setting = KodiPlugin(ADDON_ID).get_setting

_store = []  # One connection per process, opened on first use


def get_tally_plugin_setting(setting_id):
    """ Setting from plugin.video.tally or an empty string when it is not installed or disabled """
    from xbmcaddon import Addon
    try:
        return Addon(TALLY_PLUGIN_ID).getSetting(setting_id)
    except RuntimeError:
        return ''


def open_store():
    """ Tally's tracking database or None when plugin.video.tally is not installed or enabled """
    import os
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    from tmdbhelper_sync_tally.tallystore import load_store_module
    try:
        addon = Addon(TALLY_PLUGIN_ID)
    except RuntimeError:
        return
    lib_dir = os.path.join(translatePath(addon.getAddonInfo('path')), 'resources', 'lib')
    profile = translatePath(addon.getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return load_store_module(lib_dir).Store(os.path.join(profile, TALLY_DB_NAME))


def get_store():
    if not _store:
        _store.append(open_store())
    return _store[0]


def get_tally_reload():
    """ Token plugin.video.tally changes after anything it tracks changes: the time in milliseconds """
    from jurialmunkey.window import get_property
    return get_property(TALLY_RELOAD_PROPERTY, prefix=-1)


def set_tally_reload():
    """ Tell plugin.video.tally to refresh its widgets """
    import time
    from jurialmunkey.window import get_property
    get_property(TALLY_RELOAD_PROPERTY, set_property=f'{int(time.time() * 1000)}', prefix=-1)
