from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.sync.providers.base import SyncProvider
from tmdbhelper_sync_tally.sync import synctype, datasync
from tmdbhelper_sync_tally.actions import basic
from tmdbhelper_sync_tally.actions.progress import ItemProgress
from tmdbhelper_sync_tally.scrobbler import ProviderScrobbler


class Provider(SyncProvider):
    interface_version = 3
    provider_id = 'tally'
    display_name = 'Tally'
    sync_classes = {
        'SyncWatched': synctype.SyncWatched,
        'SyncPlayback': synctype.SyncPlayback,
        'SyncNextEpisodes': synctype.SyncNextEpisodes,
        'SyncAllNextEpisodes': synctype.SyncAllNextEpisodes,
        'SyncWatchlist': synctype.SyncWatchlist,
        'SyncAiredEpisodes': synctype.SyncWatched,  # Aired and watched counts come with watched shows
    }
    action_classes = {
        'watched': basic.ItemWatched,
        'unwatched': basic.ItemUnwatched,
        'watchlist': basic.ItemWatchlist,
        'progress': ItemProgress,
    }
    getter_classes = {
        'movies_to_watch': datasync.TallySyncDataGetterAllUnHiddenMoviesToWatch,
        'shows_to_watch': datasync.TallySyncDataGetterAllUnHiddenShowsToWatch,
        'shows_in_progress': datasync.TallySyncDataGetterAllUnHiddenShowsInProgress,
    }
    scrobbler_class = ProviderScrobbler

    @cached_property
    def api(self):
        return self.get_api()

    def get_api(self):
        """ Tally keeps everything in a local database, so its "API" is that database """
        from tmdbhelper_sync_tally.tally import get_store
        return get_store()

    def is_authorized(self):
        return self.api is not None

    def get_last_activities(self):
        from tmdbhelper_sync_tally.sync.activity import TallyLastActivities
        data = TallyLastActivities(self.api).data
        if not data:
            return
        return {
            item_type: {
                'watchlisted_at': data['watchlisted_at'],
                'paused_at': data['episode_paused_at' if item_type == 'episodes' else 'paused_at'],
                'watched_at': data['watched_at' if item_type == 'movies' else 'episode_watched_at'],
                'dropped_at': None,
            } for item_type in ('movies', 'shows', 'seasons', 'episodes')
        }
