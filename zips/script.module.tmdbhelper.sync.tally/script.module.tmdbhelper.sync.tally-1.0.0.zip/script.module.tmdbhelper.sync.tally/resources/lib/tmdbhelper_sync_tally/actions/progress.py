from jurialmunkey.parser import try_int
from tmdbhelper_sync_tally.actions.item import ItemSync, TallyResponse
from tmdbhelper.lib.script.sync.progress import ItemProgress as BasicItemProgress


class ItemProgress(ItemSync, BasicItemProgress):

    def get_tally_response(self):
        if self.item_type == 'movie':
            self.tally_store.clear_progress('movie', self.tmdb_id)
        else:
            self.tally_store.clear_progress('episode', self.tmdb_id, try_int(self.season), try_int(self.episode))
        return TallyResponse(True)
