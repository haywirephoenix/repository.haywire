from jurialmunkey.ftools import cached_property
from jurialmunkey.parser import try_int
from tmdbhelper.lib.addon.tmdate import is_unaired_timestamp


IMAGE_URL = 'https://image.tmdb.org/t/p/{}{}'


def image(path, size):
    return IMAGE_URL.format(size, path) if path else ''


class TallyTMDb:
    """
    What Tally stores about a title, from TMDbHelper's cached TMDb requests
    Tally's own service fills in anything missed here (ids, seasons, next episode) when it next runs
    """

    def __init__(self, tmdb_type, tmdb_id):
        self.tmdb_type = tmdb_type
        self.tmdb_id = tmdb_id

    @cached_property
    def tmdb_api(self):
        from tmdbhelper.lib.api.tmdb.api import TMDb
        return TMDb()

    @cached_property
    def details(self):
        return self.tmdb_api.get_request_sc(self.tmdb_type, self.tmdb_id) or {}

    def get_season(self, season):
        return self.tmdb_api.get_request_sc('tv', self.tmdb_id, 'season', season) or {}

    @cached_property
    def meta(self):
        """ Ids, title, year and poster for Tally's media table """
        date = self.details.get('release_date') or self.details.get('first_air_date') or ''
        return {
            'title': self.details.get('title') or self.details.get('name') or '',
            'year': try_int(date[:4]) or None,
            'poster': image(self.details.get('poster_path'), 'w500'),
            'imdb': self.details.get('imdb_id') or '',
        }

    @cached_property
    def seasons(self):
        """ [[season, episode count], ...] as Tally stores a show's structure """
        return [
            [i['season_number'], int(i.get('episode_count') or 0)]
            for i in self.details.get('seasons') or [] if i.get('season_number') is not None
        ]

    @cached_property
    def last_aired(self):
        last = self.details.get('last_episode_to_air') or {}
        if last.get('season_number') is None or last.get('episode_number') is None:
            return
        return [last['season_number'], last['episode_number']]

    @cached_property
    def ended(self):
        return self.details.get('status') in ('Ended', 'Canceled')

    def aired_episodes(self, season=None):
        """ (season, episode) of every aired episode of the show (specials left out) or of one season """
        numbers = [season] if season is not None else [i for i, _ in self.seasons if i]
        return [
            (number, i['episode_number'])
            for number in numbers
            for i in self.get_season(number).get('episodes') or []
            if not is_unaired_timestamp(i.get('air_date'))
        ]

    def update_show(self, store):
        """ After plays of a show changed: its seasons (when Tally has none yet) and next episode's details """
        if store.show_structure(self.tmdb_id) is None and self.seasons:
            store.set_show_structure(self.tmdb_id, self.seasons, self.last_aired, self.ended)
        row = store.get('tv', self.tmdb_id)
        if not row or row.get('next_season') is None:
            return
        season, episode = row['next_season'], row['next_episode']
        found = next((
            i for i in self.get_season(season).get('episodes') or []
            if i.get('episode_number') == episode), {})
        store.set_next_meta(
            self.tmdb_id, season, episode, found.get('name') or '', image(found.get('still_path'), 'w780'),
            found.get('overview') or '', found.get('air_date') or '')
