from jurialmunkey.ftools import cached_property
from jurialmunkey.parser import try_int
from tmdbhelper_sync_tally.actions.item import ItemSync, TallyResponse
from tmdbhelper.lib.script.sync.actions import (
    ItemWatched as BasicItemWatched,
    ItemUnwatched as BasicItemUnwatched,
    ItemWatchlist as BasicItemWatchlist,
)


class ItemWatched(ItemSync, BasicItemWatched):
    """ One play of a movie or episode; a season or show is every aired episode of it """

    @cached_property
    def episodes(self):
        return self.get_episodes()

    def get_episodes(self):
        if self.item_type == 'episode':
            return [(try_int(self.season), try_int(self.episode))]
        return self.tmdb.aired_episodes(try_int(self.season) if self.item_type == 'season' else None)

    def get_tally_response(self):
        store = self.tally_store
        if self.item_type == 'movie':
            store.add_play('movie', self.tmdb_id, meta=self.tmdb.meta)
            return TallyResponse(True)
        if not self.episodes:
            return TallyResponse(False, 'No aired episodes to mark')
        store.add_plays(self.tmdb_id, self.episodes, meta=self.tmdb.meta)
        self.tmdb.update_show(store)
        return TallyResponse(True)


class ItemUnwatched(ItemWatched, BasicItemUnwatched):
    """ Removes every play of the movie or of each episode """

    def get_episodes(self):
        season = try_int(self.season) if self.item_type in ('season', 'episode') else None
        plays = self.tally_store.episode_playcounts(self.tmdb_id, season)
        if self.item_type == 'episode':
            return [i for i in plays if i == (season, try_int(self.episode))]
        return list(plays)

    def get_tally_response(self):
        store = self.tally_store
        if self.item_type == 'movie':
            return TallyResponse(bool(store.remove_play('movie', self.tmdb_id)))
        if not self.episodes:
            return TallyResponse(False)
        for season, episode in self.episodes:
            store.remove_play('episode', self.tmdb_id, season, episode)
        self.tmdb.update_show(store)
        return TallyResponse(True)


class ItemWatchlist(ItemSync, BasicItemWatchlist):
    """ Tally's watchlist is any title with the Planning status: only titles with nothing watched """

    def get_tally_response(self):
        store = self.tally_store
        if self.remove:
            return TallyResponse(store.remove_watchlist(self.tally_kind, self.tmdb_id))
        if store.add_watchlist(self.tally_kind, self.tmdb_id, self.tmdb.meta):
            return TallyResponse(True)
        return TallyResponse(False, 'Already tracked in Tally')
