from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.addon.dialog import busy_decorator
from tmdbhelper.lib.script.sync.provider import ItemSync as ProviderItemSync


class TallyResponse:
    """ The outcome of a change to Tally's database, shaped like the HTTP responses TMDbHelper checks """

    def __init__(self, changed, message=''):
        self.status_code = 200 if changed else 404
        self.message = message

    def __bool__(self):
        return True  # Always answered, so TMDbHelper reports a failure rather than staying silent


class ItemSync(ProviderItemSync):
    tally_kinds = {'movie': 'movie', 'show': 'tv', 'season': 'tv', 'episode': 'tv'}

    @cached_property
    def tally_store(self):
        return self.sync_provider.api

    @cached_property
    def is_available(self):
        return self.get_is_available()

    def get_is_available(self):
        return bool(self.tally_store)

    def get_self(self):
        if not self.is_available:
            return
        return super().get_self()

    @cached_property
    def tally_kind(self):
        return self.tally_kinds[self.item_type]

    @cached_property
    def tmdb(self):
        from tmdbhelper_sync_tally.actions.meta import TallyTMDb
        return TallyTMDb(self.tally_kind, self.tmdb_id)

    def get_status_code_message(self):
        return self.sync_response.message or 'Nothing to change in Tally'

    def get_tally_response(self):
        raise NotImplementedError

    @busy_decorator
    def get_sync_response(self):
        if not self.is_available:
            return
        try:
            return self.get_tally_response()
        except Exception as exc:  # Database busy or broken
            from tmdbhelper.lib.addon.logger import kodi_log
            kodi_log(f'Tally sync action failed for {self.tmdb_type} {self.tmdb_id}: {exc}', 1)
            return TallyResponse(False, f'Tally: {exc}')

    def reset_lastactivities(self):
        super().reset_lastactivities()
        if not self.is_successful_sync:
            return
        from tmdbhelper_sync_tally.tally import set_tally_reload
        set_tally_reload()
