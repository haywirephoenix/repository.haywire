from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.monitor.scrobble import ScrobbleRequest
from tmdbhelper_sync_tally.actions.item import TallyResponse


class ProviderScrobbler(ScrobbleRequest):
    """
    Save TMDbHelper playback to Tally's database: resume points while playing, a play when stopped past 80%
    The 80% matches TMDbHelper's Trakt behaviour
    """

    @cached_property
    def is_tally_plugin_tracking(self):
        """ plugin.video.tally's service tracks all playback itself so defer to it rather than log plays twice """
        from tmdbhelper_sync_tally.tally import get_setting, get_tally_plugin_setting
        return bool(get_setting('defer_scrobbling')) and get_tally_plugin_setting('track_external') != 'false'

    def get_scrobbler_item(self):
        if self.is_tally_plugin_tracking:
            return
        player = self.player
        item = {
            'tmdb_id': f'{player.tmdb_id}',
            'position': int(player.current_time),
            'duration': int(player.total_time),
        }
        if player.tmdb_type == 'movie':
            return {**item, 'kind': 'movie', 'season': None, 'episode': None}
        if player.tmdb_type == 'tv' and player.season >= 0 and player.episode > 0:
            return {**item, 'kind': 'episode', 'season': player.season, 'episode': player.episode}

    def send_request(self, method, payload):
        store = self.provider.api
        if not store:
            return
        kind, tmdb_id, season, episode = payload['kind'], payload['tmdb_id'], payload['season'], payload['episode']
        try:
            from tmdbhelper_sync_tally.actions.meta import TallyTMDb
            tmdb = TallyTMDb('movie' if kind == 'movie' else 'tv', tmdb_id)
            if method == 'stop' and self.player.progress >= 80:
                store.add_play(kind, tmdb_id, season, episode, meta=tmdb.meta)
                if kind == 'episode':
                    tmdb.update_show(store)
            else:
                store.save_progress(
                    kind, tmdb_id, payload['position'], payload['duration'], season, episode, meta=tmdb.meta)
        except Exception as exc:  # Database busy or broken
            from tmdbhelper.lib.addon.logger import kodi_log
            kodi_log(f'Tally scrobble failed for {kind} {tmdb_id}: {exc}', 1)
            return TallyResponse(False)
        return TallyResponse(True)

    def get_result(self, method, response):
        result = super().get_result(method, response)
        if result.successful and method == 'stop':
            from tmdbhelper_sync_tally.tally import set_tally_reload
            set_tally_reload()
        return result
