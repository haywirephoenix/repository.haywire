"""
Load Tally's own tracking database code (plugin.video.tally resources/lib/store.py)
Plain Python so tests can load it from a checkout of plugin.video.tally
"""
import os
import sys
import importlib
import importlib.util


# Tally's resources/lib is loaded under its own name: TMDbHelper's process has its own "resources"
TALLY_PACKAGE = 'tmdbhelper_sync_tally_lib'


def load_store_module(lib_dir):
    """ Tally's store module from its resources/lib folder """
    if TALLY_PACKAGE not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            TALLY_PACKAGE, os.path.join(lib_dir, '__init__.py'), submodule_search_locations=[lib_dir])
        package = importlib.util.module_from_spec(spec)
        sys.modules[TALLY_PACKAGE] = package
        spec.loader.exec_module(package)
    return importlib.import_module(f'{TALLY_PACKAGE}.store')
