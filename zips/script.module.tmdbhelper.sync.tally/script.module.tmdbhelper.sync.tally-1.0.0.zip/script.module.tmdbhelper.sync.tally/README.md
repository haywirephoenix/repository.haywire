# TMDbHelper Sync - Tally

A [TMDbHelper](https://github.com/jurialmunkey/plugin.video.themoviedb.helper) sync provider (interface version 3) for [Tally](https://github.com/haywirephoenix/plugin.video.tally), which keeps watched status, resume points and a watchlist in a small database inside Kodi. No server and no account.

TMDbHelper finds it automatically once installed, because the add-on ID starts with `script.module.tmdbhelper.sync.`. Tally is not in TMDbHelper's catalogue of trusted providers, so TMDbHelper shows a third-party warning the first time you select it.

## Requirements

- TMDbHelper 6.19.0 or newer (the release with modular sync providers)
- Tally (`plugin.video.tally`) installed and enabled. Its database is read and written directly, through Tally's own code, so both add-ons always agree.

## Install

1. Install **TMDbHelper Sync - Tally (Installer)** from repository.haywire (or this add-on's zip). Kodi brings this module, Tally and TMDbHelper with it.
2. In TMDbHelper's settings, choose **Tally** for history/progress, watchlist and, if you want, scrobbling.

## What it syncs

| TMDbHelper feature | From Tally |
|---|---|
| Watched movies | Every play of each movie |
| Watched episodes and show progress | Every play of each episode. A show's aired count is watched episodes plus Tally's episodes left |
| Resume points | Tally's resume points |
| Next episodes | Tally's Next Up: the next aired episode of each show in progress |
| Up next (all unwatched episodes) | TMDb episodes compared against synced watched episodes |
| Watchlist | Movies and shows with the Planning status |

Tally has no dropped status or collection, so TMDbHelper does not offer Tally for them.

## Actions

- **Mark watched / unwatched**: a season or show is marked one aired episode at a time (specials left out); unwatching removes every play.
- **Watchlist add / remove**: only titles with nothing watched can be on Tally's watchlist, as in Tally itself.
- **Remove resume point**: clears Tally's saved position.

After marking episodes, the show's seasons and next episode are stored too, so Tally's Next Up is right straight away.

## Scrobbling

Tally's service already tracks every video Kodi plays (Tally → Settings → Tracking → **Track videos played outside Tally**), TMDbHelper's included. While that is on, this provider stands down so plays are not logged twice. Turn off **Let the Tally add-on record playback when it tracks videos** in this add-on's settings to always scrobble from TMDbHelper: resume points while playing, a play when stopped past 80%.

## Keeping in step with Tally

Tally has no last-activities record, so changes are detected from each list's size and newest entry. A removal still resyncs.

The add-on also shares the `tally.widget_reload` Home window property with `plugin.video.tally`:

- It sets the property after its own actions and stops, so Tally refreshes its widgets.
- It resyncs when Tally changes anything (the property holds the time of the change).

## Tests

`python -m unittest discover tests` from this folder, with plugin.video.tally checked out next to it.

## Licence

GPL-3.0-or-later. Structure adapted from [script.module.tmdbhelper.sync.floppy](https://github.com/haywirephoenix/script.module.tmdbhelper.sync.floppy) and [script.module.tmdbhelper.sync.mdblist](https://github.com/jurialmunkey/script.module.tmdbhelper.sync.mdblist).
